/* =====================================================================
   config/aset.js — daftar aset (gambar sheet & suara)
   Path relatif ke folder assets/.
   • SHEETS & SOUNDS di bawah diisi otomatis oleh tiap file combo/serangan
     lewat field `sheets:{}` dan `sounds:{}` pada Combos.add(...).
     (Jadi aset milik combo ditulis DI FILE COMBO-nya, bukan di sini.)
   • SOUNDS di sini hanya suara dasar: jalan, lari, taunt, kena, meleset.
   ===================================================================== */
const SHEETS = {};   // diisi oleh Combos.add({ sheets:{ kunci:'path.png' } })

const SOUNDS = {
  walk: 'suara/gerak/walk.mp3', walk2: 'suara/gerak/walk2.mp3', run: 'suara/gerak/run.mp3', taunt: 'suara/gerak/taunt.mp3',
  hit1: 'suara/serangan/kena_musuh_1.mp3', hit2: 'suara/serangan/kena_musuh_2.mp3', hit3: 'suara/serangan/kena_musuh_3.mp3',
  miss: 'suara/serangan/meleset.mp3',
};
