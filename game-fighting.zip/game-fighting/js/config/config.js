/* =====================================================================
   config/config.js — SEMUA PENGATURAN UMUM + PEMETAAN TOMBOL
   (daftar combo TIDAK di sini lagi: tiap combo punya file sendiri di js/combos/
    dan tombol pemicunya ditulis di field `keys` pada file combo itu)
   ===================================================================== */
const CFG = {
  W: 1280, H: 720, GY: 600,        // ukuran kanvas & garis tanah
  CS: 1.2,                          // skala karakter
  FPS: 30,                          // animasi dasar 30 FPS
  SW: 3200,                         // lebar dunia
  OPP_DIST: 300,                    // jarak awal lawan dari pemain
  OPP_HP: 300,                      // darah lawan latihan
  CHAIN_WINDOW: 0.55,               // detik: waktu menyambung serangan berantai setelah gerakan selesai
  MOD_WINDOW: 0.6,                  // detik: tombol modifier (L1/R1/R2) yang baru ditekan masih berlaku untuk combo
  // Kombo ✕ → □ → △ punya 2 variasi (B & C). Isi 'acak' | 'B' | 'C' | 'selang'
  VARIASI_X_KOTAK_SEGITIGA: 'acak',
};

/* Tombol keyboard (event.code) -> aksi. Ubah di sini kalau mau ganti tombol. */
const KEYMAP = {
  ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down', ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
  KeyQ: 'L1', KeyE: 'R1', KeyF: 'R2', ShiftLeft: 'L2', ShiftRight: 'L2',
  KeyI: 'TRI', KeyJ: 'SQ', KeyK: 'X', Space: 'X', KeyL: 'CI',
  KeyR: 'TAUNT',
};
const KEY_DEBUG = { KeyH: 'hurt', KeyN: 'ko', KeyB: 'revive', KeyY: 'resetOpp' };
/* Tombol gamepad (layout standar / PlayStation) -> aksi */
const PADMAP = { 0: 'X', 1: 'CI', 2: 'SQ', 3: 'TRI', 4: 'L1', 5: 'R1', 6: 'L2', 7: 'R2', 11: 'TAUNT' };
const HOLD_ACTIONS = new Set(['up', 'down', 'left', 'right', 'L1', 'CI', 'R1', 'R2']); // sisanya = tekan sekali

/* Nama aksi yang boleh dipakai di field `keys` combo:
   modifier : L1  R1  R2          tombol wajah : SQ(□)  X(✕)  TRI(△)  CI(○)
   contoh   : keys:'R2+SQ'  (tahan R2 lalu □)   keys:'TRI'  (△ saja) */
const GLYPH = { SQ: '□', X: '✕', TRI: '△', CI: '○', L1: 'L1', R1: 'R1', R2: 'R2', L2: 'L2', TAUNT: 'R' };
const GLYPH_COLOR = { SQ: '#ff6fb5', X: '#8cc4ff', TRI: '#3ddc97', CI: '#ff7b7b', L1: '#c9d1ff', R1: '#9cf', R2: '#c9d1ff', L2: '#c9d1ff', TAUNT: '#ffd27a' };
