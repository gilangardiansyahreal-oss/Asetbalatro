/* system/render.js — kanvas, kamera, variabel global dunia, dan fungsi menggambar petarung/sel sprite.
   Variabel penting: camX (kamera), GT/RT (waktu game/nyata), hitstop, shake(n), GY (tanah), CS (skala karakter). */
const cv = document.getElementById('c'), ctx = cv.getContext('2d', { alpha: false });
const W = CFG.W, H = CFG.H, GY = CFG.GY, CS = CFG.CS, FPS = CFG.FPS, SW = CFG.SW, R = Math.random;
const el = (x, y, a, b) => { ctx.beginPath(); ctx.ellipse(x, y, a, b, 0, 0, 7); ctx.fill(); };
const $ = s => document.querySelector(s);
let camX = 0, camBias = 0, camBiasT = 0, shk = 0, GT = 0, RT = 0, GS = 1.25, hitstop = 0;
const now = () => GT, nowR = () => RT;
const shake = a => shk = Math.max(shk, a);

/* sel 256px dari sheet 3x3 */
function drawCell(img, f, x, y, sc) { ctx.drawImage(img, (f % 3) * 256, Math.floor(f / 3) * 256, 256, 256, x, y, 256 * sc, 256 * sc); }
/* masuk ke ruang lokal skill: origin = kaki pemain, x+ = arah hadap, skala k */
function localBegin(ox, face, k) { ctx.save(); ctx.translate(ox - camX, GY); ctx.scale(face * k, k); }
const localEnd = () => ctx.restore();

/* ===== menggambar petarung dari frame 30 FPS ===== */
function fighter(f, X, yAir, flip, flash, im2) {
  const im = im2 || f.im, w = f.w * CS, h = f.h * CS, b = GY + 4 - yAir - (249 - f.b) * CS;
  ctx.save(); ctx.translate(X - camX, 0); if (flip) ctx.scale(-1, 1); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
  const dx = (f.l - 128) * CS; ctx.drawImage(im, dx, b - h, w, h);
  if (flash > 0) { ctx.globalAlpha = Math.min(.6, flash * 3); ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(im, dx, b - h, w, h); }
  ctx.restore();
}
/* sel sheet 256px, jangkar (ax, ay) di (X, tanah) dengan skala sc */
function cellActor(img, f, X, yAir, face, ax, ay, sc, flash) {
  ctx.save(); ctx.translate(X - camX, GY + 4 - yAir); ctx.scale(face, 1); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, (f % 3) * 256, Math.floor(f / 3) * 256, 256, 256, -ax * sc, -ay * sc, 256 * sc, 256 * sc);
  if (flash > 0) { ctx.globalAlpha = Math.min(.6, flash * 3); ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(img, (f % 3) * 256, Math.floor(f / 3) * 256, 256, 256, -ax * sc, -ay * sc, 256 * sc, 256 * sc); }
  ctx.restore();
}
