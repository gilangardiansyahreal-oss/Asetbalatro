/* system/input.js — keyboard, gamepad, dan tombol layar.
   Pemetaan tombol ada di config/config.js (KEYMAP, PADMAP). Tombol "ditekan sekali" diteruskan ke Combat.press(aksi). */
const K = {}, KB = {}, GP = {}, EDGE = {};   // K=tombol efektif, KB=keyboard/layar, GP=gamepad, EDGE=pemicu sekali (L2/TAUNT/debug)
function btnEl(k) { return document.querySelector(`[data-k="${k}"]`); }
function actionDown(a) {
  Snd.init(); Snd.resume();
  if (a === 'L2' || a === 'TAUNT') { EDGE[a] = 1; return; }
  if (HOLD_ACTIONS.has(a)) KB[a] = 1;
  if (!['up', 'down', 'left', 'right'].includes(a)) Combat.press(a);
  btnEl(a) && btnEl(a).classList.add('on');
}
function actionUp(a) { if (HOLD_ACTIONS.has(a)) KB[a] = 0; btnEl(a) && btnEl(a).classList.remove('on'); }
const keyDownSet = new Set();
addEventListener('keydown', e => {
  const a = KEYMAP[e.code], d = KEY_DEBUG[e.code]; if (!a && !d) return; e.preventDefault(); if (e.repeat) return;
  Snd.init(); Snd.resume(); if (d) { EDGE[d] = 1; return; }
  if (keyDownSet.has(a + e.code)) return; keyDownSet.add(a + e.code); actionDown(a);
});
addEventListener('keyup', e => {
  const a = KEYMAP[e.code]; if (!a) return; keyDownSet.delete(a + e.code);
  // jangan lepas jika tombol lain dengan aksi sama masih ditekan
  if ([...keyDownSet].some(s => s.startsWith(a))) return; actionUp(a);
});
document.querySelectorAll('[data-k]').forEach(b => {
  const a = b.dataset.k;
  b.addEventListener('pointerdown', e => { e.preventDefault(); b.setPointerCapture(e.pointerId); actionDown(a); });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(v => b.addEventListener(v, () => actionUp(a)));
});
document.querySelectorAll('[data-t]').forEach(b => b.addEventListener('pointerdown', e => { e.preventDefault(); Snd.init(); EDGE[b.dataset.t] = 1; }));
const padPrev = {};
function pollPad() {
  const g = [...(navigator.getGamepads ? navigator.getGamepads() : [])].find(x => x); if (!g) return;
  const b = i => g.buttons[i] && g.buttons[i].pressed, ax = g.axes;
  GP.up = b(12) || ax[1] < -.5; GP.down = b(13) || ax[1] > .5; GP.left = b(14) || ax[0] < -.5; GP.right = b(15) || ax[0] > .5;
  for (const i in PADMAP) {
    const a = PADMAP[i], d = b(i);
    if (d && !padPrev[i]) { if (a === 'L2' || a === 'TAUNT') { EDGE[a] = 1; Snd.init(); } else { Snd.init(); if (HOLD_ACTIONS.has(a)) GP[a] = 1; Combat.press(a); } }
    if (!d && padPrev[i] && HOLD_ACTIONS.has(a)) GP[a] = 0;
    padPrev[i] = d;
  }
}
