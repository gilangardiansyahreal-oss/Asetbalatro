/* system/background.js — latar arena (langit, gunung, pohon, tanah) yang di-cache. */
const BGC = {}; const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
function bgBuild() {
  let c, a, g;
  c = mk(W, GY); a = c.getContext('2d'); g = a.createLinearGradient(0, 0, 0, GY); g.addColorStop(0, '#1b1544'); g.addColorStop(.5, '#6a2f6b'); g.addColorStop(.8, '#ee6b5c'); g.addColorStop(1, '#ffc27a'); a.fillStyle = g; a.fillRect(0, 0, W, GY); BGC.sky = c;
  c = mk(560, 560); a = c.getContext('2d'); g = a.createRadialGradient(280, 280, 8, 280, 280, 280); g.addColorStop(0, '#fff6cf'); g.addColorStop(.12, '#ffd27a'); g.addColorStop(1, '#ffd27a00'); a.fillStyle = g; a.fillRect(0, 0, 560, 560); BGC.sun = c;
  c = mk(W + 220, GY); a = c.getContext('2d'); a.fillStyle = '#43285f'; a.beginPath(); a.moveTo(0, GY);
  for (let x = 0; x <= W + 220; x += 20) { const w = x; a.lineTo(x, GY - 70 - Math.max(0, 170 - Math.abs(((w + 300) % 1500) - 750) * .5) - Math.sin(w * .011) * 14); } a.lineTo(W + 220, GY); a.fill(); BGC.far = c;
  c = mk(W + 440, GY); a = c.getContext('2d'); a.fillStyle = '#2b1c49'; a.beginPath(); a.moveTo(0, GY);
  for (let x = 0; x <= W + 440; x += 20) { const w = x; a.lineTo(x, GY - 44 - Math.sin(w * .006) * 26 - Math.sin(w * .017) * 10); } a.lineTo(W + 440, GY); a.fill(); BGC.mid = c;
  const sp = 250, OX = sp; BGC.OX = OX; c = mk(W + 800 + 2 * sp, GY); a = c.getContext('2d'); a.strokeStyle = '#17122e'; a.fillStyle = '#17122e'; a.lineWidth = 7;
  for (let n = -1; n <= Math.ceil((W + 800) / sp) + 1; n++) {
    const x = n * sp + 60 + OX, h = 130 + (n * 37 % 5 + 5) % 5 * 14, lx = x + ((n % 2) ? 30 : -30);
    a.lineWidth = 7; a.beginPath(); a.moveTo(x, GY); a.quadraticCurveTo(x + (lx - x) * .2, GY - h * .6, lx, GY - h); a.stroke(); a.lineWidth = 4;
    for (let k = 0; k < 7; k++) { const an = -Math.PI * (k / 6); a.beginPath(); a.moveTo(lx, GY - h); a.quadraticCurveTo(lx + Math.cos(an) * 45, GY - h - 38 + Math.sin(an) * 10, lx + Math.cos(an) * 78, GY - h + 16 - Math.sin(an) * 8); a.stroke(); }
  } BGC.palm = c;
  c = mk(W + 60, H - GY + 20); a = c.getContext('2d'); g = a.createLinearGradient(0, 20, 0, H - GY + 20); g.addColorStop(0, '#76593f'); g.addColorStop(1, '#1e1511'); a.fillStyle = g; a.fillRect(0, 20, W + 60, H - GY);
  a.fillStyle = '#4f8a3c'; a.fillRect(0, 18, W + 60, 12); a.fillStyle = '#78b552';
  for (let x = -20; x < W + 40; x += 13) { const h = 5 + ((x * 7) % 9); a.beginPath(); a.moveTo(x + 20, 18); a.lineTo(x + 23, 18 - h); a.lineTo(x + 26, 18); a.fill(); }
  a.fillStyle = '#a9835f44'; a.fillRect(0, 32, W + 60, 26); BGC.gnd = c;
  c = mk(W, H); a = c.getContext('2d'); g = a.createRadialGradient(W / 2, H / 2, H * .45, W / 2, H / 2, H * .95); g.addColorStop(0, '#0000'); g.addColorStop(1, '#0006'); a.fillStyle = g; a.fillRect(0, 0, W, H); BGC.vig = c;
}
function bg(t) {
  const c = camX; if (!BGC.sky) bgBuild();
  ctx.drawImage(BGC.sky, 0, 0); ctx.drawImage(BGC.sun, 880 - c * .04 - 280, GY - 110 - 280);
  ctx.fillStyle = '#ffb9a844'; for (let i = 0; i < 5; i++) { const x = ((i * 330 + t / 120) % 1700) - 200 - c * .1, y = 90 + i % 3 * 55; el(x, y, 120, 15); el(x + 70, y - 9, 70, 13); }
  ctx.drawImage(BGC.far, -c * .12, 0); ctx.drawImage(BGC.mid, -c * .3, 0); ctx.drawImage(BGC.palm, -BGC.OX - c * .6, 0); ctx.drawImage(BGC.gnd, -20 - (c % 13), GY - 20);
  ctx.fillStyle = '#00000030'; for (let i = 0; i < 90; i++) { ctx.fillRect(((i * 173 + 40) % 1700 - c) % W + (((i * 173 + 40) % 1700 - c) < 0 ? W : 0), GY + 14 + (i * 53 % 90), 3 + i % 4, 2); }
}
