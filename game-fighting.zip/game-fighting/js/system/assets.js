/* system/assets.js — pemuat gambar & data. Semua file dipanggil dari folder assets/ (relatif),
   jadi bisa langsung di-upload ke GitHub Pages. (Versi 1-file memakai window.__EMBED, lihat build_satu_file.py)
   Daftar aset: SHEETS & SOUNDS (config/aset.js) + tambahan dari tiap combo (Combos.add({sheets,sounds,load})). */
const Assets = {
  embed: (typeof window !== 'undefined' && window.__EMBED) || null,
  url(p) { return this.embed ? (this.embed[p] || 'assets/' + p) : 'assets/' + p; },
  img(p) {
    return new Promise(ok => {
      const i = new Image();
      i.onload = () => ok(i);
      i.onerror = () => { console.warn('Gagal memuat gambar:', p); ok(i); };
      i.src = this.url(p);
    });
  },
  async bytes(p) {
    const u = this.url(p);
    if (u.startsWith('data:')) {
      const b = atob(u.split(',')[1]), a = new Uint8Array(b.length);
      for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i);
      return a.buffer;
    }
    const r = await fetch(u);
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + p);
    return r.arrayBuffer();
  },
};

const IMG = {};              // gambar bernama (sheet sprite): IMG.kunciSheet
const FXI = [], SMI = [];    // 20 efek biru, 23 efek asap
const AN = {};               // animasi dasar 30 FPS: AN.idle.fr[i] = {im,l,b,w,h}

async function loadAssets(progress) {
  let done = 0, total = 0;
  const bump = () => { done++; progress && progress(done / total); };
  const jobs = [];
  const add = (p, set) => { total++; jobs.push(Assets.img(p).then(i => { set(i); bump(); })); };
  for (const k in SHEETS) add(SHEETS[k], i => IMG[k] = i);                                   // semua sheet (basic + combo)
  DATA.files.fx.forEach((f, n) => add('efek/biru/' + f, i => FXI[n] = i));
  DATA.files.sm.forEach((f, n) => add('efek/asap/' + f, i => SMI[n] = i));
  Combos.loaders.forEach(fn => fn(add));                                                      // aset tambahan milik combo (field `load`)
  for (const name in MANIFEST) {
    AN[name] = { fr: new Array(MANIFEST[name].fr.length), ev: MANIFEST[name].ev };
    MANIFEST[name].fr.forEach((f, n) => add('karakter/frames_30fps/' + f.f, i => AN[name].fr[n] = { im: i, l: f.l, b: f.b, w: f.w, h: f.h }));
  }
  await Promise.all(jobs);
}
