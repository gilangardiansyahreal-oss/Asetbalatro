/* system/hud.js — tampilan di atas kanvas: banner besar, urutan tombol, hitungan HIT, toast, bar energi, panel bantuan combo. */
function banner(t, c, sub = '') { const b = $('#bn'); b.innerHTML = t + (sub ? `<small>${sub}</small>` : ''); b.style.color = c; b.classList.remove('show'); void b.offsetWidth; b.classList.add('show'); }
const LB = { idle: 'Diam', walk: 'Jalan', run: 'Lari', crouch: 'Jongkok', block: 'Bertahan (L1 tahan)', jump: 'Lompat', taunt: 'Taunt (R)', hurt: 'Kena damage', ko: 'K.O.', rise: 'Bangkit', charge: 'Mengumpulkan energi (tahan ○)', act: 'Menyerang' };

function drawHUD(t) {
  // baris urutan tombol aktif (dipakai combo bertahap, mis. lompat tinggi △ → ✕ → □)
  if (Combat.hudT > 0 && Combat.hud) {
    const h = Combat.hud, keys = h.keys;
    ctx.save(); ctx.globalAlpha = Math.min(1, Combat.hudT * 2);
    keys.forEach((k, i) => {
      const x = 40 + i * 54, y = 112, done = i < h.step, bad = i === h.bad, cl = GLYPH_COLOR[k] || '#fff';
      ctx.lineWidth = i === h.step ? 4 : 3; ctx.strokeStyle = bad ? '#ff4444' : cl; ctx.fillStyle = bad ? '#ff4444' : done ? cl : '#12162acc';
      ctx.beginPath(); ctx.arc(x, y, 21, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = done || bad ? '#0f1220' : cl; ctx.font = `bold ${GLYPH[k].length > 1 ? 16 : 22}px system-ui`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(GLYPH[k], x, y + 1);
    });
    ctx.restore();
  }
  // hitungan combo
  if (Combat.chain && Combat.chain.step >= 2 && (Combat.hitShow > 0 || Combat.chainWin > 0 || PL.act)) {
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.font = 'bold 48px system-ui'; ctx.lineWidth = 6; ctx.strokeStyle = '#000'; ctx.fillStyle = '#ffd23c';
    ctx.strokeText(Combat.chain.step + ' HIT', 30, 260); ctx.fillText(Combat.chain.step + ' HIT', 30, 260);
  }
  if (Combat.toast) { const T = Combat.toast; ctx.globalAlpha = Math.min(1, T.l * 3); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.font = '800 34px system-ui'; ctx.lineWidth = 6; ctx.strokeStyle = '#000'; ctx.fillStyle = T.c; ctx.strokeText(T.t, W / 2, 190); ctx.fillText(T.t, W / 2, 190); ctx.globalAlpha = 1; }
  // bar energi
  if (PL.energy > 1) {
    ctx.fillStyle = '#000a'; ctx.fillRect(2.5 * W / 100 - 2, 60, 244, 14); ctx.fillStyle = PL.energy >= 99 ? '#bfe6ff' : '#3b8bff'; ctx.fillRect(2.5 * W / 100, 62, 240 * PL.energy / 100, 10);
    ctx.fillStyle = '#fff'; ctx.font = 'bold 12px system-ui'; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillText(PL.energy >= 99 ? 'ENERGI PENUH' : 'ENERGI', 2.5 * W / 100 + 4, 56);
  }
}

/* panel bantuan di bawah game — dibuat otomatis dari semua combo yang terdaftar (Combos.legend) */
function buildLegend() {
  const box = $('#combos');
  box.innerHTML = Combos.legend().map(c => `<div class="cb"><div class="cn">${c.nama}</div><div class="cs">${c.seq.map(k => `<span class="g" style="color:${GLYPH_COLOR[k]};border-color:${GLYPH_COLOR[k]}">${GLYPH[k]}</span>`).join(c.plus ? '<i>+</i>' : '<i>→</i>')}${c.hold ? '<em>(tahan)</em>' : ''}</div><div class="ck">${c.ket}</div></div>`).join('');
}
