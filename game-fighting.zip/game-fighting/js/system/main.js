/* system/main.js — loop utama (update + gambar), kamera, status bar, dan start game. */
let lab = '', lm = '', last = performance.now(), fn = 0, ft = performance.now();

function step(q) {
  if (hitstop > 0) { hitstop -= q; return; }
  updPlayer(q); Combat.update(q); Charge.update(q);
  if (PL.act) PL.act.update(q);
  Combos.worldCall('update', q);          // efek dunia milik combo (gedung Kopdes, ompreng terbang, dst)
  Opp.update(q); updFxWorld(q);
}
function draw(t) {
  ctx.save(); ctx.clearRect(0, 0, W, H); if (shk > .3) ctx.translate((R() - .5) * shk, (R() - .5) * shk * .7);
  bg(t); Combos.worldCall('drawBack');
  const P = PL, sh = Math.max(.4, 1 - P.y / 400); ctx.fillStyle = '#0000004d'; el(P.x - camX + 6, GY + 8, (P.st === 'ko' || P.st === 'rise' ? 95 : 62) * sh, 9 * sh);
  if (P.act && P.act.drawBack) P.act.drawBack();
  Opp.draw(t);
  if (P.act) P.act.drawActor();
  else if (P.charging) Charge.drawActor();
  else { fighter(playerFrame(t), P.x, P.y, P.face < 0, P.flash); if (P.blk) drawShield(t); drawEmote(t); }
  if (P.act && P.act.drawFront) P.act.drawFront();
  if (P.charging) Charge.drawFront(t);
  Combos.worldCall('draw'); drawSP(); Combos.worldCall('drawFront'); drawFxWorld();
  ctx.drawImage(BGC.vig, 0, 0); ctx.restore(); drawHUD(t);
}
function loop() {
  const rt = performance.now(), dt = Math.min(.1, (rt - last) / 1000); last = rt; GT += dt * 1000 * GS; RT += dt * 1000; const t = GT; pollPad();
  let rem = dt; while (rem > 1e-4) { const q = Math.min(rem, 1 / 60); try { step(q); } catch (e) { console.error(e); if (PL.act) { PL.act = null; go('idle'); } } rem -= q; }
  fn++; if (rt - ft > 500) { $('#fp').textContent = 'ANIMASI 30 FPS · layar ' + Math.round(fn * 1000 / (rt - ft)) + ' fps · kecepatan ×' + GS; fn = 0; ft = rt; }
  const mid = Math.abs(Opp.x - PL.x) < 900 ? (PL.x + Opp.x) / 2 : PL.x; camBias += (camBiasT - camBias) * Math.min(1, dt * 3);
  const tx = Math.max(0, Math.min(SW - W, mid - W / 2 + 80 + camBias)); camX += (tx - camX) * Math.min(1, dt * 5); shk *= Math.pow(.015, dt);
  $('#h1').style.width = PL.hp + '%'; $('#h2').style.width = (100 * Opp.hp / CFG.OPP_HP) + '%';
  let l = LB[PL.st] || ''; if (PL.act) l = 'Skill: ' + Combos.label(PL.act.name); if (PL.blk && PL.st === 'crouch') l = 'Jongkok + Bertahan';
  if (l !== lab) { lab = l; $('#stl').textContent = 'Status: ' + l; }
  const m = 'MODE: ' + (PL.run ? 'LARI ⚡' : 'JALAN 🚶'); if (m !== lm) { lm = m; $('#md').textContent = m; $('#md').style.color = PL.run ? '#ffd27a' : '#9fe3ff'; const b2 = btnEl('L2'); b2 && b2.classList.toggle('on', PL.run); }
  try { draw(t); } catch (e) { console.error(e); cv.width = cv.width; } requestAnimationFrame(loop);
}

(async () => {
  buildLegend();
  $('#sp').onclick = () => { GS = GS === 1 ? 1.25 : GS === 1.25 ? 1.5 : 1; $('#sp').textContent = '⏩ Kecepatan ×' + GS; };
  $('#mu').onclick = () => { Snd.init(); Snd.setMute(!Snd.mute); $('#mu').textContent = Snd.mute ? '🔇 Suara' : '🔊 Suara'; };
  try {
    await Promise.all([loadAssets(p => { $('#ld').textContent = 'Memuat aset… ' + Math.round(p * 100) + '%'; }), Snd.preload(SOUNDS)]);
    buildOpponent(); PL.x = 500; Opp.reset(); camX = 0;
    $('#ld').remove(); addEventListener('pointerdown', () => { Snd.init(); Snd.resume(); }, { once: true });
    banner('FIGHT!', '#ffd27a', 'Round 1'); loop();
  } catch (e) { $('#ld').textContent = 'Gagal memuat: ' + e.message + ' — buka lewat GitHub Pages / server lokal (python3 -m http.server).'; console.error(e); }
})();
