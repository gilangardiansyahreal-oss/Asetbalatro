/* system/effects.js — efek dunia: asap/impact (spr, dust), teks damage, percikan, efek biru & asap lokal.
   Dipakai combo: spr(frames,x,y,opsi) · dust('lompat'|'jatuh'|'samping'|'falling',x,skala,vx) · sparks · dmgText · drawFxA/drawSmA */
const SP = [], TXT = [], PART = [];
function spr(set, x, y, o = {}) { SP.push({ im: set, x, y, t: RT, fps: o.fps || 12, sc: o.sc || 1, anc: o.anc || 'b', add: o.add, vx: o.vx || 0, a: o.a == null ? 1 : o.a }); }
const SM = {  // kumpulan frame asap sesuai nama
  get lompat() { return SMI.slice(0, 6); }, get jatuh() { return SMI.slice(6, 12); },
  get samping() { return SMI.slice(12, 17); }, get falling() { return SMI.slice(17, 23); },
};
const FXS = { get hit() { return FXI.slice(4, 8); }, get sw() { return [FXI[10], FXI[11], FXI[12], FXI[19]]; } };
const dust = (set, x, sc, vx) => spr(SM[set], x, GY + 8, { sc, vx });
function drawSP() {
  for (let i = SP.length - 1; i >= 0; i--) {
    const s = SP[i], k = (RT - s.t) / 1000 * s.fps | 0;
    if (k >= s.im.length) { SP.splice(i, 1); continue; }
    const im = s.im[k], w = im.width * s.sc, h = im.height * s.sc, x = s.x + s.vx * (RT - s.t) / 1000 - camX;
    let dx = x - w / 2, dy = s.y - h; if (s.anc === 'c') dy = s.y - h / 2; if (s.anc === 'r') { dx = x - w * .92; dy = s.y - h / 2; }
    ctx.globalAlpha = s.a * (k === s.im.length - 1 ? .7 : 1); ctx.globalCompositeOperation = s.add ? 'lighter' : 'source-over';
    ctx.drawImage(im, dx, dy, w, h);
  }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
function dmgText(t, x, y, c) { TXT.push({ t, x, y, c, l: .8, vy: -60 }); }
function sparks(x, y, face, n = 8) { for (let i = 0; i < n; i++) PART.push({ x, y: y + R() * 30 - 15, vx: R() * 300 * face, vy: -R() * 250, l: .3 }); }
function updFxWorld(dt) {
  for (let i = TXT.length - 1; i >= 0; i--) { const p = TXT[i]; p.l -= dt; p.y += p.vy * dt; if (p.l <= 0) TXT.splice(i, 1); }
  for (let i = PART.length - 1; i >= 0; i--) { const p = PART[i]; p.l -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 900 * dt; if (p.l <= 0) PART.splice(i, 1); }
}
function drawFxWorld() {
  PART.forEach(p => { ctx.fillStyle = 'rgba(255,230,140,' + (p.l / .3) + ')'; ctx.fillRect(p.x - camX, p.y, 5, 5); });
  TXT.forEach(p => { ctx.globalAlpha = Math.min(1, p.l * 2); ctx.fillStyle = p.c; ctx.strokeStyle = '#000'; ctx.lineWidth = 4; ctx.font = 'bold 34px system-ui'; ctx.textAlign = 'center'; ctx.strokeText(p.t, p.x - camX, p.y); ctx.fillText(p.t, p.x - camX, p.y); });
  ctx.globalAlpha = 1;
}
/* efek biru (aditif) & asap pada transformasi kanvas saat ini (dipakai skill dalam ruang lokal) */
function drawFxA(i, x, y, sc, rot, al) {
  const m = DATA.FXA[i], im = FXI[i]; if (!im) return;
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = al == null ? 1 : al; ctx.translate(x, y); ctx.rotate(rot || 0);
  ctx.drawImage(im, -m[2] * sc, -m[3] * sc, m[0] * sc, m[1] * sc); ctx.restore();
}
function drawSmA(i, x, y, sc, al) {
  const m = DATA.SMA[i], im = SMI[i]; if (!im) return;
  ctx.save(); ctx.globalAlpha = al == null ? .95 : al; ctx.drawImage(im, x - m[2] * sc, y - m[3] * sc, m[0] * sc, m[1] * sc); ctx.restore();
}
