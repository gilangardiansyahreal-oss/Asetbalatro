/* system/audio.js — suara: file mp3 (WebAudio) + efek sintesis. Dipakai lewat objek Snd.
   Snd.play(nama,{off,dur,vol,fade,loop,rate,norm}) memutar potongan mp3 yang didaftarkan di SOUNDS. */
const Snd = {
  ctx: null, master: null, noise: null, buf: {}, raw: {}, mute: false, peaks: {},
  init() {
    if (this.ctx) { this.resume(); return; }
    try {
      const C = window.AudioContext || window.webkitAudioContext;
      this.ctx = new C(); this.master = this.ctx.createGain(); this.master.gain.value = this.mute ? 0 : .9;
      this.master.connect(this.ctx.destination);
      this.noise = this.ctx.createBuffer(1, this.ctx.sampleRate * 2, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.decodeAll();
    } catch (e) { this.ctx = null; }
  },
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); this.decodeAll(); },
  setMute(m) { this.mute = m; if (this.master) this.master.gain.value = m ? 0 : .9; },
  async preload(map) {
    await Promise.all(Object.keys(map).map(async k => { try { this.raw[k] = await Assets.bytes(map[k]); } catch (e) { console.warn('Suara gagal:', k, e); } }));
    this.decodeAll();
  },
  decodeAll() {
    if (!this.ctx) return;
    for (const k in this.raw) {
      if (this.buf[k] || !this.raw[k] || this['_d' + k]) continue;
      this['_d' + k] = 1;
      const copy = this.raw[k].slice(0);
      const p = this.ctx.decodeAudioData(copy, b => { this.buf[k] = b; }, () => { this['_d' + k] = 0; });
      if (p && p.catch) p.catch(() => {});
    }
  },
  peak(name, off, dur) {
    const key = name + off + dur; if (this.peaks[key]) return this.peaks[key];
    const b = this.buf[name], c = b.getChannelData(0); let pk = .01;
    for (let k = off * b.sampleRate | 0, e = Math.min(c.length, (off + dur) * b.sampleRate | 0); k < e; k += 8) pk = Math.max(pk, Math.abs(c[k]));
    return this.peaks[key] = pk;
  },
  /* putar file: vol (puncak, jika norm) / gain, off & dur = potongan (detik), loop = ulang terus */
  play(name, o = {}) { try { return this._play(name, o); } catch (e) { return null; } },
  fb(n) { if (!this.ctx || this.mute) return; if (/^hit|Kick|Punch/.test(n)) this.S(t => { this.tn(t, .14, 'sine', 180, 60, .7); this.nz(t, .1, 'lowpass', 2000, 1, .5, 300); }); else if (n === 'miss' || /Slide|run|walk|Air/.test(n)) this.S(t => this.nz(t, .25, 'bandpass', 1500, 1, .18, 400)); },
  _play(name, o = {}) {
    const c = this.ctx, b = this.buf[name]; if (!c || !b) { this.decodeAll(); this.fb(name); return null; }
    const off = o.off || 0, dur = o.dur || Math.max(.05, b.duration - off), rate = o.rate || 1, fade = o.fade == null ? .06 : o.fade;
    let g = o.vol == null ? 1 : o.vol; if (o.norm) g = g / this.peak(name, off, dur);
    const t = c.currentTime, s = c.createBufferSource(), v = c.createGain(); s.buffer = b; s.playbackRate.value = rate;
    const d = dur / rate; v.gain.setValueAtTime(0, t); v.gain.linearRampToValueAtTime(g, t + .01);
    if (o.loop) { s.loop = true; s.loopStart = off; s.loopEnd = off + dur; s.start(t, off); }
    else { v.gain.setValueAtTime(g, t + Math.max(.01, d - fade)); v.gain.linearRampToValueAtTime(0, t + d); s.start(t, off, dur); }
    s.connect(v); v.connect(this.master);
    return { stop: (f = .1) => { const tt = c.currentTime; try { v.gain.cancelScheduledValues(tt); v.gain.setValueAtTime(v.gain.value, tt); v.gain.linearRampToValueAtTime(0, tt + f); s.stop(tt + f + .02); } catch (e) {} } };
  },
  /* ---- sintesis (sama dengan game dasar) ---- */
  T() { return this.ctx.currentTime; },
  S(f) { if (this.ctx) f(this.ctx.currentTime); },
  nz(t, dur, type, f, q, g, fe) {
    const c = this.ctx, s = c.createBufferSource(); s.buffer = this.noise; const fl = c.createBiquadFilter(); fl.type = type;
    fl.frequency.setValueAtTime(f, t); if (fe) fl.frequency.exponentialRampToValueAtTime(fe, t + dur); fl.Q.value = q;
    const n = c.createGain(); n.gain.setValueAtTime(.0001, t); n.gain.exponentialRampToValueAtTime(g, t + .01); n.gain.exponentialRampToValueAtTime(.0001, t + dur);
    s.connect(fl); fl.connect(n); n.connect(this.master); s.start(t, Math.random()); s.stop(t + dur + .05);
  },
  tn(t, dur, type, f0, f1, g) {
    const c = this.ctx, o = c.createOscillator(), n = c.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    n.gain.setValueAtTime(.0001, t); n.gain.exponentialRampToValueAtTime(g, t + .01); n.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(n); n.connect(this.master); o.start(t); o.stop(t + dur + .05);
  },
  vox(t, f0, f1, dur, g, v) {
    const c = this.ctx, o = c.createOscillator(), n = c.createGain(), a = c.createBiquadFilter(), b = c.createBiquadFilter();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur); a.type = b.type = 'bandpass';
    a.frequency.value = v[0]; b.frequency.value = v[1]; a.Q.value = b.Q.value = 4; n.gain.setValueAtTime(.0001, t); n.gain.exponentialRampToValueAtTime(g, t + .02);
    n.gain.exponentialRampToValueAtTime(.0001, t + dur); o.connect(a); o.connect(b); a.connect(n); b.connect(n); n.connect(this.master); o.start(t); o.stop(t + dur + .05);
  },
  VW: { a: [800, 1200], u: [350, 800], o: [500, 900], e: [450, 1900] },
  GN: { walk: 3.2, walk2: 2.8, run: 1.8, taunt: 1 },
  SWK: [['walk', .31, .48], ['walk', .91, .48], ['walk', 1.51, .48], ['walk2', .43, .5], ['walk2', 1.13, .5], ['walk2', 1.56, .44]],
  SRN: [['run', 0, .34], ['run', .34, .35], ['run', .69, .33]],
  wi: 0, ri: 0, TS: null,
  step(run) { const s = run ? this.SRN[this.ri++ % 3] : this.SWK[this.wi++ % 6]; this.play(s[0], { off: s[1], dur: s[2], vol: this.GN[s[0]], fade: .1 }); },
  tauntPlay() { this.tauntStop(); this.TS = this.play('taunt', { off: 0, dur: 3.81, vol: 1, fade: .25 }); },
  tauntStop() { if (this.TS) this.TS.stop(.12); this.TS = null; },
  jump() { this.S(t => { this.nz(t, .28, 'bandpass', 300, 1, .3, 2200); this.vox(t, 150, 230, .16, .3, this.VW.u); this.tn(t, .1, 'sine', 180, 300, .1); }); },
  land() { this.S(t => { this.tn(t, .22, 'sine', 130, 45, .85); this.nz(t, .16, 'lowpass', 800, 1, .5, 150); this.nz(t, .05, 'bandpass', 2500, 2, .2); }); },
  cr(d) { this.S(t => { d ? (this.nz(t, .17, 'bandpass', 1500, .9, .22, 600), this.tn(t + .02, .12, 'sine', 120, 66, .35)) : this.nz(t, .15, 'bandpass', 600, .9, .17, 1600); }); },
  guard(d) { this.S(t => { d ? (this.nz(t, .18, 'bandpass', 900, 1, .26, 2300), this.tn(t + .1, .09, 'sine', 95, 70, .35), this.nz(t + .12, .05, 'lowpass', 1200, 1, .25)) : this.nz(t, .15, 'bandpass', 2000, 1, .16, 700); }); },
  block() { this.S(t => { this.tn(t, .4, 'triangle', 1320, 1290, .22); this.tn(t, .2, 'square', 880, 860, .07); this.nz(t, .09, 'highpass', 3500, .5, .4); this.tn(t, .14, 'sine', 95, 58, .45); this.nz(t, .12, 'lowpass', 1800, 1, .3, 300); }); },
  hurt() { this.S(t => { this.tn(t, .3, 'sine', 200, 44, .95); this.nz(t, .22, 'lowpass', 2500, .7, .7, 200); this.nz(t, .05, 'highpass', 3000, .5, .4); this.vox(t + .02, 240, 120, .22, .3, this.VW.o); }); },
  ko() { this.S(t => { this.hurt(); this.tn(t, .8, 'sine', 110, 28, 1); this.nz(t, .6, 'lowpass', 1200, .6, .6, 100); this.vox(t + .1, 260, 70, .7, .28, this.VW.a); this.tn(t + .5, .3, 'sine', 85, 34, .85); this.nz(t + .5, .18, 'lowpass', 700, 1, .4, 150); }); },
  rev() { this.S(t => [392, 523, 659].forEach((f, i) => this.tn(t + i * .11, .4, 'triangle', f, f * 1.003, .14))); },
  mode(r) { this.S(t => { r ? (this.tn(t, .09, 'triangle', 600, 950, .2), this.tn(t + .08, .12, 'triangle', 950, 1250, .18)) : (this.tn(t, .09, 'triangle', 800, 520, .2), this.tn(t + .08, .12, 'triangle', 520, 380, .18)); }); },
  pop() { this.S(t => { this.tn(t, .09, 'sine', 480, 950, .28); this.tn(t + .07, .08, 'sine', 700, 1200, .12); }); },
  fail() { this.S(t => { this.tn(t, .38, 'sawtooth', 280, 60, .22); this.nz(t, .35, 'bandpass', 3800, 2, .14, 1100); this.tn(t + .05, .2, 'sine', 110, 45, .5); }); },
  ok() { this.S(t => { this.tn(t, .1, 'triangle', 660, 990, .12); }); },
  /* suara serangan dasar: kena (acak 1-3) / meleset */
  hitSnd(big) {
    const n = 1 + (Math.random() * 3 | 0), o = n === 3 ? { off: .85, dur: .65 } : { off: 0, dur: .55 };
    this.play('hit' + n, Object.assign({ vol: big ? 1 : .8, fade: .12 }, o));
  },
  missSnd() { this.play('miss', { off: 1.65, dur: .75, vol: .7, fade: .15 }); },
  /* gemuruh/pukulan kopdes memakai potongan + normalisasi puncak (sama seperti file asli) */
  kopCrouch(k) { this.play('kopRumble1', { off: 0, dur: .36, vol: .3 + k * .12, rate: .92 + k * .06, fade: .1, norm: true }); },
  kopPunch() { this.play('kopRumble3', { off: .33, dur: 1.05, vol: .95, fade: .3, norm: true }); },
  kopRise() { this.play('kopRumble1', { off: .42, dur: 1.1, vol: 1, fade: .25, norm: true }); },
  kopSink() { this.play('kopRumble1', { off: .42, dur: .9, vol: .5, rate: .8, fade: .25, norm: true }); },
};
