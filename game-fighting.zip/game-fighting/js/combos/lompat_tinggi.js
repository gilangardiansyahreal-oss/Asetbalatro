/* =====================================================================
   combos/lompat_tinggi.js — COMBO LOMPAT TINGGI
   Tombol : △ → ✕ → □ (bertahap, tiap tombol ditekan tepat waktu; ada jendela waktu & HUD urutan)
            △ lompat tinggi ke depan → ✕ melayang → □ banting ke bawah (knockback besar)
   Catatan: SENGAJA bertahap (berbeda dari combo otomatis) — logika ada di class HighJump di bawah.
   ===================================================================== */
const HJ = { SC: .7, K: CFG.CS / .7 };
class HighJump {
  constructor() {
    this.name = 'lompat_tinggi'; this.k = HJ.K; this.ox = PL.x; this.face = PL.face; PL.act = this; PL.st = 'act'; PL.blk = false;
    if (PL.charging) Charge.stop(true);
    Object.assign(this, { x: 0, y: 0, vx: 0, vy: 0, st: 'wind', t: 0, failed: false, buf: false, win: 0, winMax: 1, stage: 1, fxs: [], rings: [], done: false });
    Combat.setHud(['TRI', 'X', 'SQ'], 1);
  }
  addFx(fr, o) { this.fxs.push(Object.assign({ fr, fps: 16, t: 0, x: 0, y: 0, s: 1, rot: 0, an: 'b', a: 1 }, o)); }
  fail(msg, at) { if (this.mid) { this.mid.stop(.1); this.mid = null; } this.failed = true; this.stage = 0; this.win = 0; Combat.setHud(['TRI', 'X', 'SQ'], 0, at); Combat.say('✖ ' + msg, '#ff7b7b'); Snd.fail(); if (this.st === 'air2') this.st = 'air1'; }
  onPress(b) {
    if (b === 'X') {
      if (this.st === 'wind' && !this.failed) this.buf = true;
      else if (this.st === 'air1' && !this.failed && this.stage === 1) this.toAir2();
    } else if (b === 'SQ') {
      if (this.st === 'wind' || (this.st === 'air1' && this.stage === 1 && !this.failed)) this.fail('Urutan salah! harus ✕ dulu', 2);
      else if (this.st === 'air2') this.dive();
    }
  }
  toAir2() {
    this.mid = Snd.play('airMid', { vol: .8 }); this.st = 'air2'; this.t = 0; this.stage = 2; this.vy = 160; this.win = 1.2; this.winMax = 1.2; Combat.setHud(['TRI', 'X', 'SQ'], 2);
    this.addFx(FXI.slice(10, 13), { fps: 10, x: this.x, y: -this.y - 70, s: 1.2, an: 'c', a: .8 }); this.addFx(FXI.slice(13, 15), { fps: 8, x: this.x + 20, y: -this.y - 100, s: 1, an: 'c' });
  }
  dive() {
    this.st = 'dive'; this.t = 0; this.stage = 3; this.vy = -1600; this.win = 0; Combat.setHud(['TRI', 'X', 'SQ'], 3);
    // bidik lawan: atur kecepatan datar supaya mendarat dekat lawan
    const tgt = (Opp.x - this.ox) * this.face / this.k - 70, tt = Math.max(.05, this.y / 1600);
    this.vx = 650;
  }
  launch() {
    Snd.play('jumpHigh', { vol: .9 }); this.st = 'air1'; this.t = 0; this.vy = 1250; this.vx = 300; this.win = this.failed ? 0 : .8; this.winMax = .8;
    this.addFx(SMI.slice(0, 6), { fps: 18, x: this.x, y: 0, s: 1 }); this.addFx(SMI.slice(12, 17), { fps: 14, x: this.x - 50, y: 0, s: .9 });
    if (this.buf && !this.failed) { this.buf = false; this.toAir2(); }
  }
  land() {
    this.y = 0; this.vx = 0; this.t = 0; this.shakeT = 0;
    if (this.st === 'dive') {
      if (this.mid) { this.mid.stop(.04); this.mid = null; } Snd.play('slamLand', { vol: .9 }); this.st = 'slam'; shake(24); Combat.say('COMBO! △ → ✕ → □', '#7dffb0');
      const hx = this.x + 40; this.addFx(SMI.slice(6, 12), { fps: 16, x: this.x, y: 0, s: 1.4 }); this.addFx(FXI.slice(4, 9), { fps: 14, x: hx, y: -40, s: 1.2, an: 'c' });
      this.addFx(FXI.slice(18, 20), { fps: 10, x: hx, y: -40, s: 1.3, an: 'c' }); this.addFx(SMI.slice(17, 23), { fps: 14, x: hx, y: 0, s: 1.2 }); this.rings.push({ x: this.x, t: 0 });
      const dx = (Opp.x - this.ox) * this.face / this.k - this.x;
      if (Math.abs(dx) < 340 && Opp.y < 30) {
        const f = 1 - Math.abs(dx) / 340 * .5, sg = dx >= 0 ? 1 : -1;
        Opp.hit({ dmg: 40, type: 'air', vx: sg * this.face * (560 * f + 80) * this.k * .8, vy: (760 * f + 200) * this.k * .8 }); Snd.hitSnd(true); hitstop = .1; Combat.hits++;
      } else Snd.missSnd();
      Combat.setHud(['TRI', 'X', 'SQ'], 4);
    } else {
      this.st = 'land'; this.addFx(SMI.slice(6, 12), { fps: 20, x: this.x, y: 0, s: .7 });
      if (this.stage > 0) this.fail(this.stage === 2 ? 'Terlambat □ — combo gagal' : 'Combo gagal', null);
    }
    this.stage = 0;
  }
  update(dt) {
    const F = this.face;
    if (this.st === 'wind') { this.t += dt; if (this.t >= .32) this.launch(); }
    else if (['air1', 'air2', 'dive'].includes(this.st)) {
      this.t += dt; const g = this.st === 'air2' ? 700 : this.st === 'dive' ? 0 : 2800;
      if (this.st !== 'dive') this.vy -= g * dt; this.y += this.vy * dt; this.x += this.vx * dt;
      if (this.win > 0 && this.st === 'air1' && this.stage === 1) { this.win -= dt; if (this.win <= 0) this.fail('Terlambat ✕ — combo gagal', 1); }
      if (this.st === 'air2') { this.win -= dt; if (this.win <= 0 && this.stage === 2) { this.fail('Terlambat □ — combo gagal', 2); this.st = 'air1'; } }
      if (this.st === 'dive' && this.t % .05 < dt) this.addFx(FXI.slice(15, 18), { fps: 20, x: this.x + 37, y: -this.y - 63, s: .9, an: 'r', rot: Math.atan2(-this.vy, Math.abs(this.vx)) });
      if (this.st === 'air2' && this.t % .12 < dt) this.addFx(FXI.slice(14, 15), { fps: 6, x: this.x + (R() - .5) * 40, y: -this.y - 60 - R() * 60, s: .8, an: 'c' });
      if (this.y <= 0) this.land();
    }
    else if (this.st === 'slam') { this.t += dt; if (this.t > .7) this.finish(); }
    else if (this.st === 'land') { this.t += dt; if (this.t > .32) this.finish(); }
    PL.x = Math.max(90, Math.min(SW - 120, this.ox + F * this.x * this.k)); this.x = (PL.x - this.ox) * F / this.k; PL.y = this.y * this.k;
    for (const f of this.fxs) f.t += dt; this.fxs = this.fxs.filter(f => f.t * f.fps < f.fr.length);
    for (const r of this.rings) r.t += dt; this.rings = this.rings.filter(r => r.t < .5);
  }
  finish() { this.done = true; PL.act = null; PL.y = 0; go('idle'); PL.post = null; PL.vy = 0; if (this.mid) this.mid.stop(.1); Combat.afterSkill(); }
  cancel() { this.done = true; PL.act = null; PL.y = 0; if (this.mid) this.mid.stop(.1); }
  pose() {
    switch (this.st) {
      case 'wind': return [0, [1, 2, 3][Math.min(2, Math.floor(this.t / .107))]];
      case 'air1': return [0, this.failed || this.stage === 0 ? (this.vy > 0 ? 5 : 6) : (this.vy > 600 ? 4 : this.vy > 0 ? 5 : 6)];
      case 'air2': return [1, 1 + Math.floor(this.t * 10) % 6];
      case 'dive': return [2, 2];
      case 'slam': return [2, this.t < .07 ? 3 : this.t < .35 ? 4 : this.t < .5 ? 6 : 7];
      case 'land': return [0, 7];
    } return [0, 0];
  }
  drawBack() {
    localBegin(this.ox, this.face, this.k);
    for (const r of this.rings) { const kk = r.t / .5, RR = 340 * Math.min(1, kk * 1.6); ctx.strokeStyle = `rgba(120,200,255,${1 - kk})`; ctx.lineWidth = 8 * (1 - kk) + 2; ctx.beginPath(); ctx.ellipse(r.x, 4, RR, RR * .16, 0, 0, 7); ctx.stroke(); ctx.fillStyle = `rgba(90,170,255,${.25 * (1 - kk)})`; ctx.fill(); }
    localEnd();
  }
  drawActor() {
    const [sh, n] = this.pose(), an = DATA.jump[sh], ax = an[0].c, b = an[n].b, img = IMG['d' + (sh + 1)];
    localBegin(this.ox, this.face, this.k); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.translate(this.x, -this.y); ctx.drawImage(img, (n % 3) * 256, Math.floor(n / 3) * 256, 256, 256, -ax * HJ.SC, -(b + 1) * HJ.SC, 256 * HJ.SC, 256 * HJ.SC); localEnd();
  }
  drawFront() {
    localBegin(this.ox, this.face, this.k);
    for (const f of this.fxs) {
      const i = Math.min(f.fr.length - 1, Math.floor(f.t * f.fps)), im = f.fr[i]; if (!im) continue;
      ctx.save(); ctx.globalAlpha = f.a; ctx.translate(f.x, f.y); ctx.rotate(f.rot); ctx.scale(f.s, f.s);
      const ox = f.an === 'r' ? -im.width * .9 : -im.width / 2, oy = f.an === 'b' ? -im.height : -im.height / 2; ctx.drawImage(im, ox, oy); ctx.restore();
    }
    localEnd();
  }
}

Combos.add({
  id: 'lompat_tinggi', nama: 'Combo lompat tinggi', keys: 'TRI', urutan: ['TRI', 'X', 'SQ'], label: 'lompat tinggi',
  ket: 'Lompat tinggi → melayang (✕) → banting ke bawah (□)',
  sheets: {
    d1: 'serangan/kombo_segitiga_x_kotak/1_lompat_tinggi.png', d2: 'serangan/kombo_segitiga_x_kotak/2_di_udara.png',
    d3: 'serangan/kombo_segitiga_x_kotak/3_turun_knockback.png',
  },
  sounds: { jumpHigh: 'suara/gerak/lompat_tinggi.mp3', airMid: 'suara/gerak/di_udara.mp3', slamLand: 'suara/gerak/mendarat_banting.mp3' },
  launch: () => new HighJump(),
});
