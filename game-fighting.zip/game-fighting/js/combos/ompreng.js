/* =====================================================================
   combos/ompreng.js — SKILL LEMPAR OMPRENG
   Tombol : tahan R1 lalu △  (keyboard: E lalu I)
   Alur   : melempar ompreng; ompreng meluncur lurus sesuai arah hadap (objek OmTray hidup di dunia, tetap jalan setelah animasi selesai)
   ===================================================================== */
const OMP = { S: 1.5, HAND: [[128, 140], [143, 108], [58, 40], [40, 49], [62, 49], [210, 77], [225, 85], [165, 125]],
  ANIM: [[1, .08], [2, .12], [3, .12], [4, .10], [5, .07], [6, .10], [7, .18]], REL: .42, SPAWN: .08, TOTAL: .8 };
OMP.K = CFG.CS / OMP.S;
/* ompreng terbang di dunia (tetap jalan walau animasi karakter selesai) */
const OmTray = {
  tr: null, air: null,
  start(x, y) { this.tr = { mode: 'hold', s: 0, x, y, fr: 0, t: 0 }; },
  release(x0, y0, F) {
    const tr = this.tr; if (!tr) return; tr.mode = 'fly'; tr.t = 0; tr.x0 = x0; tr.y0 = y0; tr.x = x0; tr.y = y0; tr.F = F;
    tr.dur = .75; Snd.play('omThrow', { vol: .9 });
    setTimeout(() => { if (this.tr && this.tr.mode === 'fly') this.air = Snd.play('omAir', { vol: .35, dur: 1.6, fade: .2 }); }, 300);
  },
  update(dt) {
    const tr = this.tr; if (!tr) return;
    if (tr.mode === 'hold') tr.s = Math.min(1, tr.s + dt / .14);
    else if (tr.mode === 'fly') {
      tr.t += dt; const p = Math.min(1, tr.t / tr.dur), tx = tr.x0 + tr.F * 950, ty = GY - 170;
      tr.x = tr.x0 + (tx - tr.x0) * p; tr.y = tr.y0 + (ty - tr.y0) * p - Math.sin(p * Math.PI) * 90; tr.fr = Math.floor(tr.t * 32) % 15;
      const hitO = Math.abs(tr.x - Opp.x) < 75 && Opp.st !== 'down' && Opp.st !== 'rise';
      if (p >= 1 || hitO) {
        const tx = tr.x; if (this.air) { this.air.stop(.05); this.air = null; } Snd.play('omHit', { vol: 1, dur: 1.2 });
        if (hitO && Opp.hit({ dmg: 25, type: 'airSmall', vx: 300 * tr.F, vy: 380 })) { hitstop = .1; shake(12); Combat.hits++; }
        sparks(tx, ty, tr.F, 22); tr.mode = 'drop'; tr.t = 0; tr.vx = -260 * -tr.F * -1; tr.vx = -260 * tr.F; tr.vy = -380; tr.fr = 3;
      }
    } else if (tr.mode === 'drop') { tr.t += dt; tr.vy += 1500 * dt; tr.x += tr.vx * dt; tr.y += tr.vy * dt; tr.fr = Math.floor(tr.t * 28) % 15; if (tr.t > .7) this.tr = null; }
  },
  draw() {
    const t = this.tr; if (!t) return; const cw = 2172 / 15, sc = .95 * OMP.K * (t.mode === 'hold' ? (1 - Math.pow(1 - t.s, 3)) : 1);
    if (t.mode === 'fly') { ctx.save(); ctx.lineCap = 'round'; for (let i = 0; i < 6; i++) { const kk = i / 5, y = t.y - 26 + i * 10, len = 60 + R() * 70; ctx.strokeStyle = 'rgba(200,225,255,' + (.5 - kk * .25) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(t.x - camX - 50 * t.F, y); ctx.lineTo(t.x - camX - (50 + len) * t.F, y + (R() - .5) * 4); ctx.stroke(); } ctx.restore(); }
    ctx.save(); ctx.translate(t.x - camX, t.y); ctx.scale(sc, sc); ctx.drawImage(IMG.omTray, Math.floor(t.fr) * cw, 270, cw, 148, -cw / 2, -75, cw, 148); ctx.restore();
  },
};
class OmprengSkill {
  constructor() {
    this.name = 'ompreng'; this.k = OMP.K; this.ox = PL.x; this.face = PL.face; PL.act = this; PL.st = 'act'; PL.blk = false;
    this.t = 0; this.spawned = false; this.released = false; this.done = false; this.hudStep = 4;
  }
  frameAt(t) { let a = 0; for (const [f, d] of OMP.ANIM) { if (t < a + d) return f; a += d; } return 0; }
  hand(f) { const S = OMP.S, h = OMP.HAND[f]; return [this.ox + this.face * (h[0] * S - 126 * S) * this.k, GY + (h[1] * S - 247 * S) * this.k]; }
  update(dt) {
    this.t += dt; const f = this.frameAt(this.t);
    if (!this.spawned && this.t >= OMP.SPAWN) { this.spawned = true; const [x, y] = this.hand(2); OmTray.start(x, y); sparks(x, y, this.face, 8); }
    const tr = OmTray.tr;
    if (tr && tr.mode === 'hold') { const [hx, hy] = this.hand(f === 7 || f === 6 ? 5 : f); tr.x += (hx - tr.x) * .55; tr.y += (hy - tr.y) * .55; }
    if (!this.released && this.t >= OMP.REL) { this.released = true; const [x, y] = this.hand(5); OmTray.release(x, y, this.face); }
    if (this.t > OMP.TOTAL + .3) this.finish();
  }
  finish() { if (this.done) return; this.done = true; PL.act = null; go('idle'); PL.post = null; Combat.afterSkill(); }
  cancel() { this.done = true; PL.act = null; }
  drawBack() { }
  drawActor() { localBegin(this.ox, this.face, this.k); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; drawCell(IMG.omLempar, this.t > OMP.TOTAL ? 0 : this.frameAt(this.t), -126 * OMP.S, -247 * OMP.S, OMP.S); localEnd(); }
  drawFront() { }
}

Combos.add({
  id: 'ompreng', nama: 'Skill Lempar Ompreng', keys: 'R1+TRI', toast: 'LEMPAR OMPRENG', label: 'Lempar Ompreng',
  ket: 'Ompreng meluncur lurus sesuai arah hadap',
  sheets: { omLempar: 'skill/ompreng/melempar.png', omTray: 'skill/ompreng/ompreng_strip.png' },
  sounds: { omThrow: 'suara/skill/ompreng_dilempar.mp3', omAir: 'suara/skill/ompreng_di_udara.mp3', omHit: 'suara/skill/ompreng_kena_musuh.mp3' },
  world: OmTray,
  launch: () => new OmprengSkill(),
});
