/* =====================================================================
   combos/kopdes.js — JURUS KOPDES
   Tombol : tahan L1 lalu △  (keyboard: Q lalu I)
   Alur   : tinju tanah → gelombang kejut → gedung Kopdes muncul di depan (menghantam lawan), lalu tenggelam lagi
   Objek  : KopWorld = gedung + gelombang + serpihan yang hidup di dunia (tetap ada setelah skill selesai)
   ===================================================================== */
const KOP = { c: [], k: [] };   // frame karakter (jurus1..8) & bangunan (kopdes1..9)
const KOPD = { CSL: 150 / 243, AX: [26, 36, 49, 58, 59, 57, 52, 41], HXL: (124 - 59) * (150 / 243) - 6, HYL: -14, BW: 1.9, DIST: 700 };
KOPD.K = CFG.CS / KOPD.CSL;
/* gedung + gelombang + serpihan hidup di dunia (tetap ada setelah skill selesai) */
const KopWorld = {
  b: null, wave: null, deb: [], cr: [], glow: 0, flash: 0,
  KT: [0, 170, 340, 520, 700, 900, 1080],
  rise(cx) { this.b = { s: 'rise', t: RT, cx }; },
  sink() { if (this.b) { this.b.s = 'sink'; this.b.t = RT; } Snd.kopSink(); shake(10); },
  debris(n, x0, x1) { for (let i = 0; i < n; i++) this.deb.push({ x: x0 + R() * (x1 - x0), y: GY + 4, vx: (R() - .5) * 260, vy: -(260 + R() * 700), l: 1.2 + R(), z: 3 + R() * 7, c: ['#8a6a52', '#6b523f', '#a98466', '#503d30', '#c9a37a'][R() * 5 | 0] }); },
  update(dt) {
    const t = RT, b = this.b;
    if (b) {
      if (b.s === 'sink' && t - b.t > 800) this.b = null;
      else if (b.s === 'rise' && t - b.t > 3600) this.sink();
      else if (b.s === 'rise' && t - b.t < 1000) this.debris(2, b.cx - 420, b.cx + 420);
    }
    if (this.wave) {
      const w = this.wave, p = (t - w.t0) / w.dur;
      if (p >= 1) this.wave = null;
      else {
        const x = w.x0 + (w.x1 - w.x0) * Math.pow(p, .85); w.x = x;
        if (t > w.ld) { w.ld = t + 55; spr(SM.samping, x, GY + 8 + R() * 10, { sc: .65 + R() * .5, fps: 10 }); this.debris(3, x - 30, x + 30); }
        this.cr.t0 = t; while (!this.cr.lx || (w.dir > 0 ? this.cr.lx < x : this.cr.lx > x)) { this.cr.lx = (this.cr.lx || w.x0) + 16 * w.dir; this.cr.push([this.cr.lx, GY + 14 + R() * 22]); }
        if (!w.hitOpp && (w.dir > 0 ? x >= Opp.x - 40 : x <= Opp.x + 40) && Math.abs(x - Opp.x) < 400) {
          w.hitOpp = true; if (Opp.hit({ dmg: 45, type: 'air', vx: 340 * w.dir, vy: 520 })) { Snd.hitSnd(true); hitstop = .12; shake(16); Combat.hits++; }
        }
      }
    }
    for (let i = this.deb.length - 1; i >= 0; i--) { const p = this.deb[i]; p.vy += 1700 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.l -= dt; if (p.y > GY + 30) { p.y = GY + 30; p.vy *= -.3; p.vx *= .6; } if (p.l <= 0) this.deb.splice(i, 1); }
    this.flash = Math.max(0, this.flash - dt * 1.6);
  },
  drawBack() {
    // retakan tanah
    if (this.cr.length > 1) {
      const a = Math.max(0, 1 - (RT - (this.cr.t0 || 0)) / 2600); ctx.lineJoin = 'round'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 3; ctx.beginPath();
      this.cr.forEach((p, i) => i ? ctx.lineTo(p[0] - camX, p[1]) : ctx.moveTo(p[0] - camX, p[1])); ctx.stroke();
      if (a > 0) { ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = `rgba(80,170,255,${a})`; ctx.lineWidth = 5; ctx.stroke(); ctx.globalCompositeOperation = 'source-over'; }
    }
    const b = this.b; if (!b) return;
    const t = RT - b.t; let fi = 6, fp = -1, al = 1, off = 0;
    if (b.s === 'rise') { if (t < 1080) { fi = 0; for (let i = 0; i < 7; i++) if (t >= this.KT[i]) fi = i; if (fi > 0) { fp = fi - 1; al = Math.min(1, (t - this.KT[fi]) / 110); } } else if (t >= 1450) fi = 7 + ((t - 1450) / 420 | 0) % 2; }
    if (b.s === 'sink') { off = (t / 780) ** 2 * 260; fi = 6; }
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, GY + 10); ctx.clip(); ctx.imageSmoothingEnabled = false;
    const d = (i, a) => { const im = KOP.k[i], w = im.width * KOPD.BW, h = im.height * KOPD.BW; ctx.globalAlpha = a; ctx.drawImage(im, b.cx - camX - w / 2, GY + 10 - h + off, w, h); };
    if (fp >= 0) d(fp, 1); d(fi, al); ctx.restore(); ctx.globalAlpha = 1;
    if (this.glow > 0) { const x = b.cx - camX, r = ctx.createRadialGradient(x, GY - 60, 10, x, GY - 60, 620); r.addColorStop(0, `rgba(255,120,90,${this.glow * .35})`); r.addColorStop(1, '#0000'); ctx.fillStyle = r; ctx.fillRect(0, 0, W, H); this.glow = Math.max(0, this.glow - .006); }
  },
  drawFront() {
    this.deb.forEach(p => { ctx.fillStyle = p.c; ctx.fillRect(p.x - camX, p.y, p.z, p.z); });
    if (this.flash > 0) { ctx.fillStyle = `rgba(190,220,255,${this.flash})`; ctx.fillRect(-20, -20, W + 40, H + 40); }
  },
};
/* pose karakter saat tombol-tombol ditekan / sesudah gagal (dipakai Combat) */
function drawKopPose(pose, charge, t) {
  const im = KOP.c[pose]; if (!im) return; const F = PL.face, S = KOPD.CSL;
  localBegin(PL.x, F, KOPD.K); ctx.translate(0, 4);
  if (charge) {
    const gx = KOPD.HXL, gy = KOPD.HYL - 10, r = 40 + 8 * Math.sin(t / 80), g = ctx.createRadialGradient(gx, gy, 2, gx, gy, r);
    g.addColorStop(0, '#fff'); g.addColorStop(.3, '#5aa9ffcc'); g.addColorStop(1, '#1b6cff00'); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = g; ctx.fillRect(gx - r, gy - r, r * 2, r * 2); ctx.globalCompositeOperation = 'source-over';
  }
  ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; ctx.drawImage(im, -KOPD.AX[pose] * S, -im.height * S, im.width * S, im.height * S); localEnd();
}
class KopSkill {
  constructor() {
    this.name = 'kopdes'; this.k = KOPD.K; this.ox = PL.x; this.face = PL.face; PL.act = this; PL.st = 'act'; PL.blk = false;
    this.t = 0; this.pose = 5; this.sp = []; this.done = false; this.hudStep = 5;
    this.q = []; const at = (ms, f) => this.q.push([ms, f]); const F = this.face, hx = KOPD.HXL, hy = KOPD.HYL;
    this.fxl = []; const add = (fr, x, y, o) => this.fxl.push(Object.assign({ fr, x, y, t: 0, fps: 12, sc: 1, anc: 'c' }, o));
    const wx = (lx) => this.ox + F * lx * this.k;
    at(0, () => { add(FXI.slice(0, 4), hx, hy - 40, { anc: 'r', fps: 30, sc: 1.1 }); });
    at(90, () => { this.pose = 4; Snd.kopPunch(); });
    at(130, () => { shake(16); KopWorld.flash = .55; add(FXI.slice(4, 9), hx + 34, hy - 34, { fps: 11, sc: 1.25 }); this.dust = true; dust('jatuh', wx(hx + 10), .95 * 1.2); add(FXI.slice(15, 20), hx + 10, hy - 26, { fps: 14, sc: 1.05 }); });
    at(300, () => { KopWorld.wave = { t0: RT, dur: 720, x0: wx(hx + 30), x1: this.ox + F * (KOPD.DIST + 380), ld: 0, dir: F }; KopWorld.cr.length = 0; KopWorld.cr.lx = 0; camBiasT = F * 170; });
    at(450, () => { add(FXI.slice(9, 15), hx + 34, hy - 34, { fps: 9, sc: 1.3 }); this.pose = 6; });
    at(820, () => this.pose = 7);
    at(1020, () => {
      const cx = this.ox + F * KOPD.DIST; for (let i = 0; i < 4; i++) setTimeout(() => { const x = cx + (i - 1.5) * 250; spr(SM.falling, x, GY + 8, { sc: 1.5, fps: 11 }); setTimeout(() => spr(SM.jatuh, x, GY + 10, { sc: 1.4, fps: 9 }), 110); }, i * 75);
      KopWorld.rise(cx); shake(26); KopWorld.glow = 1; Snd.kopRise(); KopWorld.debris(70, cx - 420, cx + 420);
      if (Math.abs(Opp.x - cx) < 520 && Opp.hit({ dmg: 60, type: 'air', vx: 240 * F, vy: 640 })) { Snd.hitSnd(true); hitstop = .15; Combat.hits++; }
    });
    at(1300, () => { this.pose = 0; dust('lompat', PL.x, .5); });
    at(2150, () => { banner('COMBO BERHASIL!', '#7dffb0'); camBiasT = 0; });
    at(2600, () => this.finish());
  }
  update(dt) {
    this.t += dt * 1000; while (this.q.length && this.q[0][0] <= this.t) this.q.shift()[1]();
    for (const f of this.fxl) f.t += dt; this.fxl = this.fxl.filter(f => f.t * f.fps < f.fr.length);
  }
  finish() { if (this.done) return; this.done = true; PL.act = null; go('idle'); PL.post = null; camBiasT = 0; Combat.afterSkill(); }
  cancel() { this.done = true; PL.act = null; camBiasT = 0; }
  drawBack() { }
  drawActor() { drawKopPose(this.pose, false, nowR()); }
  drawFront() {
    localBegin(this.ox, this.face, this.k);
    for (const f of this.fxl) {
      const i = Math.min(f.fr.length - 1, Math.floor(f.t * f.fps)), im = f.fr[i]; if (!im) continue;
      const w = im.width * f.sc, h = im.height * f.sc; let dx = f.x - w / 2, dy = f.y - h / 2; if (f.anc === 'r') { dx = f.x - w * .92; }
      ctx.globalAlpha = i === f.fr.length - 1 ? .75 : 1; ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(im, dx, dy, w, h);
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; localEnd();
  }
}

Combos.add({
  id: 'kopdes', nama: 'Jurus Kopdes', keys: 'L1+TRI', toast: 'JURUS KOPDES', label: 'Kopdes',
  ket: 'Tinju tanah → gedung Kopdes muncul di depan',
  sounds: {
    kopRumble1: 'suara/skill/kopdes_rumble1_jongkok_dan_kopdes.mp3', kopRumble3: 'suara/skill/kopdes_rumble3_pukulan.mp3',
  },
  load: add => {   // frame berseri: karakter 8 + bangunan 9
    for (let n = 1; n <= 8; n++) add('skill/kopdes/karakter/jurus' + n + '.png', i => KOP.c[n - 1] = i);
    for (let n = 1; n <= 9; n++) add('skill/kopdes/bangunan/kopdes' + n + '.png', i => KOP.k[n - 1] = i);
  },
  world: KopWorld,
  launch: () => new KopSkill(),
});
