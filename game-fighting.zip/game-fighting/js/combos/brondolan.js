/* =====================================================================
   combos/brondolan.js — SKILL BRONDOLAN
   Tombol : tahan L1 lalu ○  (keyboard: Q lalu L)
   Alur   : makan → menyemburkan brondolan lurus ke depan (peluru banyak, damage kecil tiap kena)
   ===================================================================== */
const BRON = { S: 1.3, MOUTH: [[135, 31], [130, 32], [127, 33], [132, 30], [164, 39], [176, 47], [162, 37], [144, 31]],
  ENV: [0.26, 0.98, 1.0, 0.9, 0.89, 0.92, 0.95, 0.85, 0.79, 0.62, 0.49, 0.52, 0.43, 0.48, 0.29, 0.25, 0.33, 0.39, 0.21, 0.18, 0.1, 0.11, 0.1, 0.06], EATD: 1.41, SHOTD: 1.2, BL: .05 };
BRON.K = CFG.CS / BRON.S;
class BrondolanSkill {
  constructor() {
    this.name = 'brondolan'; this.k = BRON.K; this.ox = PL.x; this.face = PL.face; PL.act = this; PL.st = 'act'; PL.blk = false;
    this.t = 0; this.cur = { s: 'eat', f: 0 }; this.proj = []; this.tick = 0; this.shotStarted = false; this.done = false; this.hitSnd = 0; this.hudStep = 4;
    Snd.play('brEat', { vol: .9 });
  }
  mouth() { const m = BRON.MOUTH[this.cur.f], S = BRON.S; return [m[0] * S - 126 * S, m[1] * S - 247 * S]; }
  update(dt) {
    this.t += dt; const E = BRON.EATD, S0 = E + .36, F = this.face, k = this.k;
    if (this.t < E) this.cur = { s: 'eat', f: Math.min(7, Math.floor(this.t / (E / 8))) };
    else if (this.t < S0) this.cur = { s: 'spit', f: Math.min(3, Math.floor((this.t - E) / .09)) };
    else {
      if (!this.shotStarted) { this.shotStarted = true; Snd.play('brShot', { vol: 1 }); }
      const el = this.t - S0;
      if (el < BRON.SHOTD) {
        const f = el < .13 * BRON.SHOTD ? 4 : el < .51 * BRON.SHOTD ? 5 : el < .79 * BRON.SHOTD ? 6 : 7; this.cur = { s: 'spit', f };
        this.tick -= dt;
        if (this.tick <= 0) {
          this.tick = .05; const e = BRON.ENV[Math.min(BRON.ENV.length - 1, (el / BRON.BL) | 0)];
          if (e > .12) { const c = Math.round(e * 5 * (.5 + R())); for (let q = 0; q < c; q++) { const [mx, my] = this.mouth(), a = -.04 + (R() - .5) * .5, v = 800 + R() * 700; this.proj.push({ x: mx + 70, y: my, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, sc: .4 + R() * .4, mf: 4 + (R() * 8 | 0), t: 0 }); } }
        }
      } else if (el > BRON.SHOTD + .25) { this.cur = { s: 'eat', f: 0 }; if (!this.proj.length || el > BRON.SHOTD + 1.4) return this.finish(); }
    }
    this.hitSnd -= dt;
    for (let i = this.proj.length - 1; i >= 0; i--) {
      const p = this.proj[i]; p.t += dt; p.x += p.vx * dt; p.vy += 500 * dt; p.y += p.vy * dt;
      const wx = this.ox + F * p.x * k, wy = GY + p.y * k;
      if (p.y > 8 || Math.abs(p.x) * k > 1700) { this.proj.splice(i, 1); continue; }
      if (Opp.st !== 'down' && Opp.st !== 'rise' && Math.abs(wx - Opp.x) < 55 && wy > GY - 330) {
        if (Opp.hit({ dmg: 2, type: 'stagger', vx: 50 * F, tm: .12 })) { this.proj.splice(i, 1); if (this.hitSnd <= 0) { this.hitSnd = .16; Snd.hitSnd(false); } sparks(wx, wy, F, 2); Combat.hits++; }
      }
    }
  }
  finish() { if (this.done) return; this.done = true; PL.act = null; go('idle'); PL.post = null; Combat.afterSkill(); }
  cancel() { this.done = true; PL.act = null; }
  drawBack() { }
  drawActor() { localBegin(this.ox, this.face, this.k); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; drawCell(IMG[this.cur.s === 'eat' ? 'brMakan' : 'brSemb'], this.cur.f, -126 * BRON.S, -247 * BRON.S, BRON.S); localEnd(); }
  drawFront() {
    localBegin(this.ox, this.face, this.k);
    this.proj.forEach(p => { const fi = Math.min(p.mf, (p.t * 40) | 0); ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(Math.atan2(p.vy, p.vx)); ctx.scale(p.sc, p.sc); ctx.drawImage(IMG.brPeluru, fi * 200, 0, 200, 100, -173, -44, 200, 100); ctx.restore(); });
    localEnd();
  }
}

Combos.add({
  id: 'brondolan', nama: 'Skill Brondolan', keys: 'L1+CI', toast: 'BRONDOLAN', label: 'Brondolan',
  ket: 'Makan lalu semburkan brondolan lurus ke depan',
  sheets: { brMakan: 'skill/brondolan/makan.png', brSemb: 'skill/brondolan/menyembur.png', brPeluru: 'skill/brondolan/peluru_strip_15frame.png' },
  sounds: { brEat: 'suara/skill/brondolan_makan.mp3', brShot: 'suara/skill/brondolan_tembakan.mp3' },
  launch: () => new BrondolanSkill(),
});
