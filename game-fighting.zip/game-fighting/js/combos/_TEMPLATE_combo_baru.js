/* =====================================================================
   _TEMPLATE_combo_baru.js — SALIN FILE INI untuk membuat combo baru
   (file ini TIDAK dimuat game; ia contoh yang jalan: memakai ulang sprite 'slide' kuda-kuda)

   LANGKAH:
   1. Salin jadi js/combos/nama_combo.js, ganti id/nama/keys/toast/label/ket.
   2. Pilih `keys` yang masih kosong (lihat docs/TOMBOL_COMBO.md).
   3. Taruh sprite sheet 5x5 (25 frame, sel 256px, transparan) & mp3 di assets/, daftarkan di `sheets` / `sounds`.
   4. Isi `tips` (posisi tangan/kaki [x,y] tiap frame) dan `stages` (format ada di combos/_engine.js).
   5. Tambah 1 baris di index.html (bagian COMBO):  <script src="js/combos/nama_combo.js"></script>
   Selesai — panel bantuan, pemuatan aset, tombol, dan HUD ikut otomatis.
   ===================================================================== */
Combos.add({
  id: 'contoh_combo', nama: 'Contoh Combo (L1 + □)', keys: 'L1+SQ',
  toast: 'CONTOH COMBO!', label: 'Contoh', ket: 'Slide kuda-kuda saja (contoh template)',

  sheets: {},   // sheet baru: { kunci: 'karakter/combo/nama.png' }   (contoh ini memakai 'ns' milik kuda_kuda)
  sounds: {},   // suara baru: { kunci: 'suara/combo/nama.mp3' }

  tips: { s: Combos.byId.kuda_kuda.tips.s },   // GANTI dengan titik ujung sprite barumu
  order: ['slide'],                            // urutan tahap, jalan otomatis

  stages: {
    slide: {
      img: 'ns', k: 's',
      f0: 7, f1: 19, ms: 58,
      xs: [[9, 0], [15, 108]],
      snd: ['cSlide', { vol: 1, fade: .1 }],
      h: { 15: { o: { dmg: 12, type: 'stagger', vx: 260, tm: .3 }, stun: 3 } },
    },
  },
});
