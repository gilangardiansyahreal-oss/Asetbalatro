/* =====================================================================
   combos/_engine.js — MESIN COMBO DEKLARATIF (jalan otomatis sekali tekan)
   Dipakai oleh combo yang punya field `stages` (contoh: combos/kuda_kuda.js).
   File ini hanya mesin — JANGAN perlu diubah untuk menambah combo. Yang perlu dibaca: format `stages` di bawah.

   FORMAT SATU TAHAP (stage) — satu tahap = satu sprite sheet 5x5 (25 frame, sel 256px):
     img   : kunci sheet di `sheets` combo          k     : kunci titik ujung di `tips` combo (posisi tangan/kaki tiap frame [x,y])
     f0,f1 : frame awal & akhir                      ms    : milidetik per frame (kecil = cepat)
     xs    : [[frame,jarak],..] geser maju (satuan lokal; 108 ≈ 1 meter, 3 meter ≈ 324)
     snd   : ['namaSound',{off,dur,vol,fade}]        suara saat tahap mulai (off/dur = potongan mp3 dalam detik)
     smoke : [frame,..] frame yang mengeluarkan asap kaki      ghost : f=>bool, frame yang meninggalkan bayangan
     tr    : [frame,..] frame yang menampilkan jejak biru di ujung tangan/kaki      trI : index efek FXI untuk jejak
     on    : {frame: s=>efek/suara tambahan}  s = skill (s.wx(x) = posisi dunia, s.x = posisi lokal, s.face = arah)
     h     : {frame: {o:{dmg,type:'stagger'|'air'|'airSmall',vx,vy,tm}, stun:detik, big:1, txt:'teks'}}  = frame yang memukul
             vx = dorongan ke depan (otomatis dikali arah hadap). type 'air' = terlempar. stun = lawan membeku sekian detik.
     cols  : (opsional) jumlah kolom sheet, default 5
   Efek dunia yang bisa dipanggil di `on`: spr(frames,x,y,opsi) · dust('lompat'|'jatuh'|'samping'|'falling',x,skala,vx) · shake(n) · hitstop=detik
   ===================================================================== */
class ComboSkill {
  constructor(id) {
    const def = this.def = Combos.byId[id];
    this.name = def.id; this.stages = def.order || Object.keys(def.stages); this.si = 0;
    this.k = def.scale || 1.58; this.ox = PL.x; this.face = PL.face;
    PL.act = this; PL.st = 'act'; PL.blk = false;
    if (PL.charging) Charge.stop(true);
    this.done = false;
    this.begin();
  }
  /* mulai tahap this.si */
  begin() {
    const C = this.C = this.def.stages[this.stages[this.si]];
    this.t = 0; this.f = C.f0; this.x = 0; this.px = 0; this.hist = [];
    if (C.snd) Snd.play(C.snd[0], C.snd[1]);
    this.fire(C.f0);
  }
  wx(lx) { return this.ox + this.face * lx * this.k; }                      // posisi lokal -> posisi dunia
  tipL(f) { const t = this.def.tips[this.C.k][f]; return [this.x + t[0] - 127, -(220 - t[1])]; }
  fire(f) {                                                                  // dipanggil sekali tiap frame baru
    const C = this.C; this.f = f;
    if (C.smoke && C.smoke.includes(f)) dust('samping', this.wx(this.x - 34), .5, -90 * this.face);
    if (C.on && C.on[f]) C.on[f](this);
    const h = C.h && C.h[f]; if (h) this.strike(h);
  }
  strike(h) {
    const [lx, ly] = this.tipL(this.f), wx = this.wx(lx), wy = GY + ly * this.k, F = this.face, dx = (Opp.x - wx) * F;
    if (Opp.st === 'down' || Opp.st === 'rise' || dx < -80 || dx > 90) { Snd.missSnd(); return; }
    const o = Object.assign({}, h.o); o.vx = (o.vx || 0) * F; if (o.type === 'air') Opp.stun = 0;
    if (!Opp.hit(o)) return;
    Combat.hits++; if (h.stun) Opp.stun = h.stun;
    Snd.hitSnd(!!h.big); hitstop = h.big ? .13 : .04; shake(h.big ? 16 : 4); sparks(wx, wy, F, h.big ? 14 : 5);
    spr(h.big ? FXS.hit.concat(FXI.slice(8, 10)) : FXS.hit, wx, wy, { anc: 'c', fps: h.big ? 16 : 24, sc: h.big ? 1.5 : .7, add: 1 });
    if (h.big) { spr(FXI.slice(18, 20), wx, wy, { anc: 'c', fps: 12, sc: 1.3, add: 1 }); spr(FXI.slice(10, 13), wx - F * 20, wy, { anc: 'c', fps: 14, sc: 1.1, add: 1 }); }
    if (h.txt) dmgText(h.txt, Opp.x, GY - 280, '#ffe14d');
  }
  update(dt) {
    const C = this.C; this.t += dt * 1000; const ff = C.f0 + this.t / C.ms;
    while (this.f < Math.floor(ff) && this.f < C.f1) this.fire(this.f + 1);
    let x = 0; const xs = C.xs;                                              // gerak maju mengikuti titik xs (halus)
    if (xs) for (let i = 0; i < xs.length; i++) {
      if (ff >= xs[i][0]) x = xs[i][1];
      if (i && ff > xs[i - 1][0] && ff < xs[i][0]) { const p = (ff - xs[i - 1][0]) / (xs[i][0] - xs[i - 1][0]), e = p * p * (3 - 2 * p); x = xs[i - 1][1] + (xs[i][1] - xs[i - 1][1]) * e; }
    }
    const ol = (Opp.x - this.ox) * this.face / this.k; if (ol > 0 && x > ol - 62) x = Math.max(this.px, Math.min(x, ol - 62));   // jangan menembus lawan
    this.px = x;
    PL.x = Math.max(90, Math.min(SW - 120, this.wx(x))); this.x = (PL.x - this.ox) * this.face / this.k;
    if (C.ghost && C.ghost(this.f)) this.hist.push({ x: this.x, f: this.f, t: this.t });
    this.hist = this.hist.filter(h => this.t - h.t < 180);
    if (ff >= C.f1 + 1) this.nextStage();
  }
  nextStage() {
    const n = this.si + 1; if (n >= this.stages.length) return this.finish();
    this.si = n; this.ox = PL.x; this.begin();
  }
  finish() { if (this.done) return; this.done = true; PL.act = null; PL.vx = 0; go('idle'); PL.post = null; Combat.afterSkill(); }
  cancel() { this.done = true; PL.act = null; }
  cell(x, f, a) { const c = this.C.cols || 5; ctx.globalAlpha = a; ctx.drawImage(IMG[this.C.img], (f % c) * 256, (f / c | 0) * 256, 256, 256, x - 127, -220, 256, 256); }
  drawBack() { }
  drawActor() {
    localBegin(this.ox, this.face, this.k); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    this.hist.forEach(h => this.cell(h.x, h.f, .28 * (1 - (this.t - h.t) / 180))); this.cell(this.x, this.f, 1); ctx.globalAlpha = 1; localEnd();
  }
  drawFront() {
    const C = this.C; if (!C.tr || !C.tr.includes(this.f)) return;
    localBegin(this.ox, this.face, this.k); const [x, y] = this.tipL(this.f); drawFxA(C.trI[this.f % C.trI.length], x - 20, y, 1, 0, .85); localEnd();
  }
}
