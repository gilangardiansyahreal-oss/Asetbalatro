/* =====================================================================
   combos/kuda_kuda.js — COMBO KUDA-KUDA
   Tombol : tahan R2 lalu □  (keyboard: F lalu J)
   Alur   : sekali picu langsung jalan sampai habis (otomatis):
            Slide 1 m → tumbukan bertubi 6x (stun 3 dtk) → tendangan pamungkas terpental ±3 m
   Arah   : sesuai arah hadap pemain (tanpa auto-bidik).
   Sheet  : 5x5 (25 frame, sel 256px). Format tahap: lihat combos/_engine.js
   ===================================================================== */

/* satu pukulan tumbukan kecil (dipakai berulang di tahap `bertubi`) */
const KUDA_TUMBUK = { o: { dmg: 4, type: 'stagger', vx: 30, tm: .2 }, stun: 3 };

Combos.add({
  id: 'kuda_kuda', nama: 'COMBO Kuda-kuda (R2 + □)', keys: 'R2+SQ',
  toast: 'COMBO KUDA-KUDA!', label: 'Kuda-kuda',
  ket: 'Sekali picu langsung jalan sampai habis: Slide 1 m → tumbukan bertubi 6x (stun 3 dtk) → tendangan pamungkas terpental ±3 m',

  /* ---- aset milik combo ini ---- */
  sheets: { ns: 'karakter/combo/slide.png', np: 'karakter/combo/bertubi.png', nk: 'karakter/combo/tendang.png' },
  sounds: { cSlide: 'suara/combo/slide.mp3', cPunch: 'suara/combo/bertubi.mp3', cKick: 'suara/combo/tendang.mp3' },

  /* ---- titik ujung tangan/kaki [x,y] tiap frame (0..24) pada sel 256px, dipakai untuk efek & jarak pukul ---- */
  tips: {
    s: [[148, 125],[148, 125],[148, 125],[148, 125],[148, 125],[148, 125],[147, 128],[146, 132],[163, 122],[163, 98],[157, 92],[161, 109],[183, 131],[190, 112],[191, 116],[191, 117],[191, 115],[190, 105],[185, 142],[164, 150],[152, 118],[150, 114],[151, 119],[150, 119],[149, 119]],
    p: [[148, 127],[148, 127],[148, 127],[148, 128],[146, 130],[161, 111],[168, 207],[203, 82],[176, 211],[205, 85],[180, 125],[176, 159],[176, 211],[206, 83],[176, 211],[211, 81],[176, 211],[195, 80],[176, 211],[193, 84],[176, 211],[228, 79],[223, 77],[176, 211],[174, 211]],
    k: [[147, 124],[147, 124],[147, 124],[147, 124],[147, 124],[152, 116],[168, 144],[186, 74],[231, 99],[232, 117],[201, 170],[173, 157],[157, 77],[163, 75],[175, 125],[208, 145],[234, 82],[237, 116],[218, 154],[172, 151],[152, 153],[146, 138],[144, 129],[144, 129],[145, 131]],
  },

  /* ---- urutan tahap: jalan otomatis dari kiri ke kanan ---- */
  order: ['slide', 'bertubi', 'tendang'],

  /* ---- definisi tiap tahap ---- */
  stages: {
    slide: {
      img: 'ns', k: 's',           // sheet yang dipakai (jangan diubah kalau sheet sama) & kunci titik ujung di `tips`
      f0: 7, f1: 19,               // mulai dari frame 7, selesai di frame 19
      ms: 58,                      // kecepatan, tiap frame 58 milidetik (kecil = lebih cepat)
      xs: [[9, 0], [15, 108]],     // maju: di frame 9 posisi 0, di frame 15 sudah maju 108
      snd: ['cSlide', { vol: 1, fade: .1 }],
      smoke: [10, 11, 12, 13, 14, 15, 16],      // frame yang mengeluarkan asap kaki
      ghost: f => f >= 10 && f <= 17,           // frame yang meninggalkan bayangan
      on: {                                      // efek tambahan per frame
        9: s => { dust('lompat', s.wx(s.x - 10), .55); shake(3); },
        15: s => spr(FXI.slice(10, 13), s.wx(s.x + 30), GY - 80, { anc: 'c', fps: 14, sc: .9, add: 1 }),
        18: s => dust('jatuh', s.wx(s.x + 10), .4),
      },
      h: { 15: { o: { dmg: 12, type: 'stagger', vx: 260, tm: .3 }, stun: 3 } },   // frame 15 memukul
    },

    bertubi: {
      img: 'np', k: 'p',
      f0: 5, f1: 23, ms: 36,
      snd: ['cPunch', { off: 0, dur: .95, vol: 1, fade: .15 }],
      tr: [6, 8, 12, 14, 16, 20], trI: [0, 1, 2, 3],   // jejak biru di tangan pada frame-frame ini
      on: { 6: s => dust('samping', s.wx(s.x - 20), .4, -60 * s.face) },
      h: {
        7: KUDA_TUMBUK, 9: KUDA_TUMBUK, 13: KUDA_TUMBUK, 15: KUDA_TUMBUK, 17: KUDA_TUMBUK,
        21: { o: { dmg: 10, type: 'stagger', vx: 60, tm: .2 }, stun: 3, big: 1, txt: 'STUN 3 DETIK!' },
      },
    },

    tendang: {
      img: 'nk', k: 'k',
      f0: 5, f1: 24, ms: 52,
      snd: ['cKick', { off: .85, dur: .5, vol: 1, fade: .1 }],
      tr: [7, 15], trI: [10, 11, 12],
      smoke: [15, 16],
      ghost: f => f >= 15 && f <= 18,
      on: { 14: s => { Snd.play('cKick', { off: 4.5, dur: .55, vol: 1, fade: .1 }); dust('falling', s.wx(s.x), .5); } },
      h: {
        8: { o: { dmg: 14, type: 'stagger', vx: 140, tm: .25 } },
        16: { o: { dmg: 40, type: 'air', vx: 520, vy: 540 }, big: 1, txt: 'TERPENTAL 3 METER!' },
      },
    },
  },
});
