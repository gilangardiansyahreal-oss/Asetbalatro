/* =====================================================================
   logic/combat.js — PENGATUR TOMBOL (otak input → serangan/combo)
   Tidak berisi data combo. Semua combo/serangan mendaftar sendiri lewat Combos.add() (lihat logic/combo-registry.js).

   Alur Combat.press(tombol):
     1. L1 / R1 / R2  → disimpan sebagai "modifier" (berlaku CFG.MOD_WINDOW detik, atau selama masih ditahan)
     2. Sedang menjalankan skill?  → tombol diteruskan ke skill (onPress) / disambung ke rantai serangan dasar
     3. modifier + tombol cocok dengan Combos.trig['R2+SQ'] dst → jalankan combo itu
     4. selain itu (cold) → sambung rantai serangan dasar (□□□□, ✕□△), atau mulai tombol tunggal (□ ✕ △ ○)
   ===================================================================== */
const Combat = {
  chain: null,      // rantai serangan dasar aktif: { def, kind, step, variant, final }
  chainWin: 0,      // sisa detik jendela menyambung rantai
  pending: null,    // tombol yang ditekan saat skill berjalan (dijalankan setelah selesai)
  hits: 0, hitShow: 0,
  mod: null, modT: 0,
  hud: null, hudT: 0, toast: null,

  setHud(keys, step, bad) { this.hud = { keys, step, bad: bad == null ? -1 : bad }; this.hudT = 2.2; },
  say(t, c) { this.toast = { t, c: c || '#fff', l: 1.4 }; },
  cancel() { if (PL.act && PL.act.cancel) PL.act.cancel(); this.chain = null; this.pending = null; this.mod = null; PL.act = null; },

  /* ===== tombol ditekan ===== */
  press(b) {
    const P = PL;
    if (b === 'L1' || b === 'R1' || b === 'R2') { this.mod = b; this.modT = CFG.MOD_WINDOW; return; }
    if (P.act) {
      if (P.act.onPress) return P.act.onPress(b);
      if (P.act.name === 'strike') return this.strikePress(b);
      return;                                        // skill lain sedang berjalan: tombol diabaikan
    }
    if (['hurt', 'ko', 'rise', 'jump'].includes(P.st) || P.land > 0) return;
    const m = (KB.L1 || GP.L1) ? 'L1' : (KB.R1 || GP.R1) ? 'R1' : (KB.R2 || GP.R2) ? 'R2' : (this.modT > 0 ? this.mod : null);
    const def = m && Combos.trig[m + '+' + b];
    if (def) { this.mod = null; this.modT = 0; this.chain = null; this.chainWin = 0; Snd.ok(); return this.launch(def); }
    this.cold(b);
  },
  launch(def) { def.launch(); if (def.toast) this.say(def.toast, '#ffd27a'); },

  /* ===== tombol tunggal / awal rantai ===== */
  cold(b) {
    if (this.chain && this.chainWin > 0 && this.chainNext(b)) return this.chainGo(b);   // menyambung rantai
    const def = Combos.trig[b];                                                         // tombol tunggal tanpa modifier
    if (!def) { this.chain = null; this.chainWin = 0; return; }
    if (!def.keepChain) { this.chain = null; this.chainWin = 0; }
    if (def.chain) return this.startChain(def);
    def.launch();
  },

  /* ===== rantai serangan dasar (data ada di field `chain` tiap serangan) ===== */
  startChain(def) {
    const c = def.chain, v = c.pick ? c.pick() : 'default';
    this.chain = { def, kind: def.id, step: 1, variant: v, final: false };
    new StrikeSkill(pick(c.pool), { kind: def.id, variant: v });
    this.chainWin = 0; this.hitShow = 0;
  },
  chainNext(b) {                                   // langkah rantai berikutnya bila tombol `b` cocok, kalau tidak null
    const c = this.chain; if (!c || c.final) return null;
    const steps = c.def.chain.variants[c.variant], s = steps[c.step - 1];
    if (!s || s.key !== b) return null;
    return { keys: [s.move], auto: s.auto, final: c.step === steps.length };
  },
  chainGo(b) {
    const nk = this.chainNext(b), c = this.chain; c.step++; if (nk.final) c.final = true; this.chainWin = 0;
    new StrikeSkill(nk.keys[0], { kind: c.kind, variant: c.variant, auto: nk.auto }); this.hitShow = 1.2;
  },
  strikePress(b) {                                 // tombol ditekan saat gerakan serangan masih berjalan
    const s = PL.act, nk = this.chainNext(b);
    if (nk && !s.next) { this.chain.step++; if (nk.final) this.chain.final = true; s.setNext(nk.keys[0]); if (nk.auto) s.auto = nk.auto; this.hitShow = 1.2; }
    else this.pending = b;
  },
  strikeEnded() {
    if (this.chain && !this.chain.final) this.chainWin = CFG.CHAIN_WINDOW; else { this.chain = null; this.chainWin = 0; }
    this.afterSkill(true);
  },
  afterSkill(keep) {
    if (!keep) { this.chain = null; this.chainWin = 0; }
    const p = this.pending; this.pending = null; if (p) this.press(p);
  },

  update(dt) {
    if (this.modT > 0) this.modT -= dt;
    if (this.chainWin > 0) { this.chainWin -= dt; if (this.chainWin <= 0) { this.chain = null; } }
    if (this.hudT > 0) this.hudT -= dt;
    if (this.toast) { this.toast.l -= dt; if (this.toast.l <= 0) this.toast = null; }
    if (this.hitShow > 0) this.hitShow -= dt;
  },
};
