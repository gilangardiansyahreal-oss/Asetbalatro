/* logic/opponent.js — LAWAN LATIHAN (samsak): kena pukul, terpental, jatuh, bangkit, stun. Objek Opp.
   Opp.hit({dmg,type:'stagger'|'air'|'airSmall',vx,vy,tm}) dipanggil oleh serangan/combo. */
const Opp = {
  x: 0, y: 0, vx: 0, vy: 0, rot: 0, stun: 0, st: 'idle', tm: 0, t: 0, hp: CFG.OPP_HP, flash: 0, sh: 0, small: false, frames: null, koWait: 0, kref: 1,
  reset() { this.x = Math.min(SW - 200, PL.x + CFG.OPP_DIST); this.y = 0; this.vx = this.vy = 0; this.rot = 0; this.st = 'idle'; this.hp = CFG.OPP_HP; this.t = 0; this.small = false; this.koWait = 0; this.stun = 0; },
  face() { return this.x > PL.x ? -1 : 1; },       // arah hadap lawan (menuju pemain)
  /* o: {dmg, type:'stagger'|'air'|'airSmall', vx (dunia, bertanda), vy (naik +), tm, shake, snd} */
  hit(o) {
    if (this.st === 'down' || this.st === 'rise') return false;
    if (this.stun > 0) { this.hp = Math.max(0, this.hp - (o.dmg || 0)); this.flash = .12; this.sh = .18; if ((o.dmg || 0) >= 3) dmgText('-' + o.dmg, this.x, GY - 210, '#ffd23c'); return true; }
    this.hp = Math.max(0, this.hp - (o.dmg || 0)); this.flash = .12; this.sh = .18; this.t = 0;
    if ((o.dmg || 0) >= 3) dmgText('-' + (o.dmg || 0), this.x, GY - 210 - this.y, o.type === 'stagger' ? '#ffd23c' : '#ff5a3c');
    if (o.type === 'stagger') { this.st = 'stagger'; this.vx = o.vx || 0; this.tm = o.tm || .28; }
    else { this.small = o.type === 'airSmall'; this.st = 'air'; this.vx = o.vx || 0; this.vy = o.vy || 300; this.y = Math.max(this.y, 1); this.tm = 0; }
    this.kref = o.kref || 1;
    return true;
  },
  update(dt) {
    this.sh = Math.max(0, this.sh - dt); this.flash = Math.max(0, this.flash - dt); this.t += dt;
    const G = 1900 * .706;
    if (this.stun > 0) { this.stun -= dt; this.vx = 0; this.st = 'stagger'; this.tm = .1; if (this.stun <= 0) { this.st = 'idle'; this.t = 0; } }
    if (this.st === 'stagger') { this.x += this.vx * dt; this.vx *= Math.pow(.02, dt); this.tm -= dt; if (this.tm <= 0) { this.st = 'idle'; this.t = 0; } }
    else if (this.st === 'air') {
      this.x += this.vx * dt; this.vy -= G * dt; this.y += this.vy * dt;
      if (this.y <= 0) {
        this.y = 0;
        if (this.small) { this.vy = 0; this.vx = 0; this.small = false; this.st = 'stagger'; this.tm = .2; this.t = 0; shake(6); }
        else if (Math.abs(this.vy) > 350 * .706) { this.vy = -this.vy * .35; this.vx *= .5; shake(8); this.y = 1; dust('jatuh', this.x, .6); }
        else { this.vy = 0; this.vx = 0; this.st = 'down'; this.tm = .9; this.t = 0; shake(10); dust('falling', this.x, .75); dust('jatuh', this.x - 40, .55); dmgText('KNOCKDOWN', this.x, GY - 120, '#ff8a5a'); }
      }
    }
    else if (this.st === 'down') { this.tm -= dt; if (this.tm <= 0) { this.st = 'rise'; this.tm = AN.ko.fr.length / FPS; this.t = 0; } }
    else if (this.st === 'rise') { this.tm -= dt; if (this.tm <= 0) { this.st = 'idle'; this.t = 0; if (this.hp <= 0) this.hp = CFG.OPP_HP; } }
    this.x = Math.max(150, Math.min(SW - 150, this.x));
    if (this.hp <= 0 && this.st === 'down') { if (!this.koWait) { this.koWait = 1; banner('K.O.', '#ffd27a', 'Lawan tumbang'); } }
    if (this.st !== 'down') this.koWait = 0;
  },
  frame(t) {
    const F = this.frames; const n = AN.ko.fr.length;
    switch (this.st) {
      case 'stagger': return this.stun > 0 ? F.hurt[Math.min(F.hurt.length - 1, 7 + ((t / 110 | 0) % 2))] : F.hurt[Math.min(F.hurt.length - 1, this.t * FPS | 0)];
      case 'air': return this.small ? F.hurt[Math.min(F.hurt.length - 1, 6 + (this.t * FPS | 0))] : F.ko[Math.min(n - 1, (this.t * FPS * .8) | 0)];
      case 'down': return F.ko[Math.min(n - 1, Math.max(n - 6, (this.t * FPS * .8 + 8) | 0))];
      case 'rise': return F.ko[Math.max(0, n - 1 - (this.t * FPS | 0))];
    }
    return F.idle[(t / 1000 * FPS | 0) % F.idle.length];
  },
  draw(t) {
    const sx = this.sh > 0 ? (R() - .5) * 8 : 0, f = this.frame(t), fl = this.face() < 0;
    ctx.fillStyle = '#0000004d'; const sh = Math.max(.4, 1 - this.y / 400); el(this.x - camX, GY + 8, (this.st === 'down' || this.st === 'rise' ? 95 : 62) * sh, 9 * sh);
    fighter(f.f, this.x + sx, this.y, fl, this.flash, f.im);
    if (this.stun > 0) { ctx.fillStyle = '#ffe14d'; ctx.font = 'bold 28px system-ui'; ctx.textAlign = 'center'; for (let i = 0; i < 3; i++) { const a = t / 180 + i * 2.09; ctx.fillText('★', this.x - camX + Math.cos(a) * 36, GY - 305 - this.y + Math.sin(a) * 9); } ctx.fillRect(this.x - camX - 30, GY - 282 - this.y, 60 * Math.min(1, this.stun / 3), 5); }
  },
};
/* warna lawan: tukar kanal merah-biru (seperti game dasar); cadangan: filter hue */
function tint(im) {
  const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const x = c.getContext('2d');
  try {
    x.drawImage(im, 0, 0); const d = x.getImageData(0, 0, c.width, c.height), p = d.data;
    for (let i = 0; i < p.length; i += 4) if (p[i + 2] > p[i] + 8) { const r = p[i]; p[i] = p[i + 2]; p[i + 2] = r; }
    x.putImageData(d, 0, 0);
  } catch (e) { x.clearRect(0, 0, c.width, c.height); x.filter = 'hue-rotate(160deg)'; x.drawImage(im, 0, 0); }
  return c;
}
function buildOpponent() {
  const mkset = n => AN[n].fr.map(f => ({ f, im: tint(f.im) }));
  Opp.frames = { idle: mkset('idle'), hurt: mkset('hurt'), ko: mkset('ko') };
  Opp.reset();
}
