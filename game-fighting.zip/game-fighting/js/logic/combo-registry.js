/* =====================================================================
   logic/combo-registry.js — DAFTAR SEMUA COMBO & SERANGAN (registry)
   Tiap file di js/basic/ dan js/combos/ mendaftarkan dirinya lewat Combos.add({...}).
   Sistem (combat.js, assets.js, hud.js, main.js) TIDAK perlu diubah saat combo baru ditambah.

   Field Combos.add(def):
     id      : nama unik (huruf kecil_garis_bawah). Dipakai juga sebagai skill.name
     nama    : teks di panel bantuan (legenda) bawah game          ket : keterangan di panel bantuan
     keys    : tombol pemicu. 'R2+SQ' = tahan R2 lalu □ · 'TRI' = △ saja (tanpa modifier)
               modifier: L1 R1 R2 · tombol: SQ(□) X(✕) TRI(△) CI(○)
     urutan  : (opsional) tampilan urutan di panel bantuan, mis. ['TRI','X','SQ'] (ditampilkan dengan panah →)
     hold    : true bila tombol ditahan (hanya tampilan label)
     toast   : teks besar yang muncul di layar saat combo dipicu   label : teks status "Skill: ..."
     sheets  : { kunci:'path/sheet.png' }  → didaftarkan ke SHEETS, nanti tersedia sebagai IMG.kunci
     sounds  : { kunci:'path/suara.mp3' }   → didaftarkan ke SOUNDS, dipakai Snd.play('kunci',{...})
     load    : add => { add('path.png', img => ...) }  → pemuatan gambar tambahan (frame berseri, dll)
     world   : objek dengan update(dt) / drawBack() / draw() / drawFront() untuk efek yang tetap hidup di dunia
               setelah skill selesai (mis. gedung Kopdes, ompreng terbang)
     --- jenis combo (pilih SATU) ---
     stages+order+tips : combo deklaratif per-tahap (lihat combos/kuda_kuda.js & combos/_engine.js)
     launch  : fungsi bebas yang memulai skill, mis. () => new KopdesSkill()  (untuk skill berbasis class)
     chain   : rantai serangan dasar (lihat basic/pukulan_kotak.js): { pool, steps | variants, pick }
   ===================================================================== */
const Combos = {
  list: [],       // semua definisi, urut sesuai urutan <script> (menentukan urutan panel bantuan)
  byId: {},       // id -> definisi
  trig: {},       // 'R2+SQ' / 'TRI' -> definisi (tabel pemicu tombol)
  loaders: [],    // fungsi pemuat aset tambahan

  add(def) {
    if (!def.id) throw new Error('Combos.add: field "id" wajib diisi');
    if (this.byId[def.id]) console.warn('[Combos] id ganda:', def.id);
    def.keys = String(def.keys || '').replace(/\s+/g, '');
    if (def.chain && !def.chain.variants) def.chain.variants = { default: def.chain.steps || [] };
    if (def.stages && !def.launch) def.launch = () => new ComboSkill(def.id);
    if (!def.launch && !def.chain) console.warn('[Combos] "' + def.id + '" tidak punya launch / stages / chain');
    Object.assign(SHEETS, def.sheets || {});
    Object.assign(SOUNDS, def.sounds || {});
    if (def.load) this.loaders.push(def.load);
    if (def.keys) {
      const p = def.keys.split('+'), btn = p.pop();
      if (!GLYPH[btn] || p.some(m => !['L1', 'R1', 'R2'].includes(m))) console.warn('[Combos] keys tidak valid pada', def.id, ':', def.keys);
      if (this.trig[def.keys]) console.warn('[Combos] tombol', def.keys, 'dipakai ganda:', this.trig[def.keys].id, '&', def.id);
      this.trig[def.keys] = def;
    }
    this.list.push(def); this.byId[def.id] = def;
    return def;
  },
  /* panggil metode `m` pada semua objek `world` milik combo (update, drawBack, draw, drawFront) */
  worldCall(m, ...a) { for (const d of this.list) { const w = d.world; if (w && w[m]) w[m](...a); } },
  /* teks status "Skill: ..." */
  label(name) { return name === 'strike' ? 'serangan' : ((this.byId[name] || {}).label || ''); },
  /* data untuk panel bantuan di bawah game */
  legend() {
    return this.list.filter(d => d.keys && d.nama).map(d => ({
      nama: d.nama, seq: d.urutan || d.keys.split('+'), plus: !d.urutan && d.keys.includes('+'), hold: !!d.hold, ket: d.ket || '',
    }));
  },
};
