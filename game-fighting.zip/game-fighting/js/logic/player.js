/* logic/player.js — PEMAIN: gerak dasar 30 FPS (jalan, lari, lompat, jongkok, tangkis, taunt), kena damage, K.O., gambar perisai/emote.
   Objek PL = state pemain. PL.act = skill/combo yang sedang jalan (null = bebas). go(state) = ganti state animasi. */
const EMO = ['😎', '😏', '💪', '🔥', '👉'];
const PL = { run: false, post: null, jt: 0, emo: null, x: 420, y: 0, vy: 0, vx: 0, jvx: 0, st: 'idle', t: 0, hp: 100, ph: 0, lf: -1, f: 0, land: 0, prep: 0, jl: false, flash: 0, blk: false, face: 1,
  act: null, holdL1: 0, charging: false, energy: 0 };
const mv = x => x === 'walk' || x === 'run';
const seq = (n, i) => { const a = AN[n].fr; return a[Math.max(0, Math.min(a.length - 1, i | 0))]; };
const pp = (n, i) => { const a = AN[n].fr, m = a.length - 1, k = Math.floor(i) % (2 * m); return a[k < m ? k : 2 * m - k]; };
function go(s) {
  const P = PL, p = P.st; if (p === s) return; P.st = s; P.t = 0; P.post = null;
  if (p === 'crouch' && s === 'idle') P.post = { n: 'cr_up', t0: now() };
  if (p === 'block' && s === 'idle') P.post = { n: 'gd_out', t0: now() };
  if (p === 'taunt') Snd.tauntStop();
  if (mv(s)) { if (mv(p)) { const o = AN[p].fr.length, n = AN[s].fr.length; P.ph = ((P.ph * FPS / o) % 1 + 1) % 1 * n / FPS; } else P.ph = (AN[s].ev[0] - 1) / FPS; }
  P.lf = -1;
  if (s === 'crouch') Snd.cr(1); if (s === 'block') Snd.guard(1); if (p === 'block' && s !== 'block') Snd.guard(0); if (p === 'crouch' && s !== 'crouch' && s !== 'jump') Snd.cr(0);
}
const canAct = () => !PL.act && ['idle', 'walk', 'run', 'crouch', 'block', 'taunt'].includes(PL.st) && !PL.land;
function playerHurt() {
  const P = PL; if (P.st === 'ko' || P.st === 'rise') return; const cx = P.x + 30, cy = GY - 150 - P.y;
  if (P.blk) { P.x -= 22 * P.face; P.hp = Math.max(1, P.hp - 2); Snd.block(); shake(5); spr(FXS.sw, P.x + 95 * P.face, cy, { anc: 'c', fps: 14, sc: .8, add: 1 }); return; }
  P.hp = Math.max(0, P.hp - 15); P.flash = .25; Snd.hurt(); shake(11); spr(FXS.hit, cx + 30, cy, { anc: 'c', fps: 16, sc: .9, add: 1 });
  if (P.hp <= 0) return playerKO(); if (P.y <= 0) { go('hurt'); P.vx = -260 * P.face; }
}
function playerKO() {
  const P = PL; if (P.st === 'ko' || P.st === 'rise') return; if (P.act && Combat.cancel) Combat.cancel();
  P.hp = 0; go('ko'); P.vx = -320 * P.face; P.flash = .3; Snd.ko(); shake(18); spr(FXS.hit, P.x + 30, GY - 150 - P.y, { anc: 'c', fps: 16, sc: 1.1, add: 1 });
  banner('K.O.', '#ff5d5d', 'Tekan B / tombol Bangkit');
}
function playerRevive() {
  const P = PL; if (P.st === 'ko' && P.t > 1.1) { go('rise'); Snd.rev(); } else if (P.st !== 'ko' && P.st !== 'rise') P.hp = 100;
}
function stepSfx() { const run = PL.st === 'run'; Snd.step(run); if (run) dust('samping', PL.x - 26 * PL.face, .32, -60 * PL.face); }

function updPlayer(dt) {
  const P = PL; dt *= (P.st === 'taunt' ? 1 : GS);
  ['up', 'down', 'left', 'right', 'L1', 'CI'].forEach(k => K[k] = KB[k] || GP[k]);
  const dir = (K.right ? 1 : 0) - (K.left ? 1 : 0); P.t += dt; P.flash = Math.max(0, P.flash - dt);
  if (EDGE.L2) { EDGE.L2 = 0; P.run = !P.run; Snd.mode(P.run); }
  if (EDGE.hurt) { EDGE.hurt = 0; playerHurt(); } if (EDGE.ko) { EDGE.ko = 0; playerKO(); } if (EDGE.revive) { EDGE.revive = 0; playerRevive(); }
  if (EDGE.resetOpp) { EDGE.resetOpp = 0; Opp.reset(); }
  if (!K.up) P.jl = false;
  P.holdL1 = K.L1 ? P.holdL1 + dt : 0;
  if (P.act) { P.blk = false; return; }           // sedang menjalankan skill: skill yang mengatur posisi
  const st = P.st;
  if (st === 'hurt') { P.x += P.vx * dt; P.vx *= Math.pow(.02, dt); if (P.t > AN.hurt.fr.length / FPS) go('idle'); }
  else if (st === 'ko') { P.x += P.vx * dt; P.vx *= Math.pow(.03, dt); }
  else if (st === 'rise') { if (P.t > AN.ko.fr.length / FPS + .05) { go('idle'); P.hp = 100; } }
  else if (st === 'jump') {
    if (P.prep > 0) { P.prep -= dt; if (P.prep <= 0) { P.vy = 980; P.jt = 0; Snd.jump(); dust('lompat', P.x, .45); } }
    else { P.jt += dt; P.x += P.jvx * dt + (P.jvx ? 0 : dir * 120 * dt); }
  }
  else if (P.land > 0) P.land -= dt;
  else if (P.charging) { /* diatur oleh skill energi */ }
  else {
    if (EDGE.TAUNT) { if (st === 'taunt') go('idle'); else { go('taunt'); Snd.tauntPlay(); Snd.pop(); P.emo = { e: EMO[R() * 5 | 0], t: now() }; } }
    if (P.st === 'taunt') { if (P.t > 3.8) go('idle'); }
    else {
      const sp = dir * (P.run ? 620 : 230); if (dir) P.face = dir;
      if (K.up && !P.jl) { P.jl = true; P.jvx = dir ? sp : 0; go('jump'); P.prep = .16; P.jt = 0; }
      else if (K.down) go('crouch');
      else if (K.L1 && P.holdL1 > .22) go('block');
      else if (dir) { go(P.run ? 'run' : 'walk'); P.x += sp * dt; }
      else go('idle');
    }
  }
  EDGE.TAUNT = 0;
  if (mv(P.st)) { const n = AN[P.st].fr.length; P.ph += dt; const f = ((Math.floor(P.ph * FPS) % n) + n) % n; if (f !== P.lf) { P.lf = f; if (AN[P.st].ev.includes(f)) stepSfx(); } }
  if (P.y > 0 || P.vy > 0) {
    P.y += P.vy * dt; P.vy -= 2500 * dt;
    if (P.y <= 0) { P.y = 0; P.vy = 0; if (P.st === 'jump') { dust('jatuh', P.x + 10, .5); Snd.land(); go('idle'); P.land = .18; P.post = { n: 'jp_ld', t0: now() - 2 / FPS * 1000 }; } }
  }
  P.x = Math.max(90, Math.min(P.x, SW - 120));
  P.blk = (P.st === 'block' || P.st === 'crouch') && !!K.L1 && P.holdL1 > .22;
}
function playerFrame(t) {
  const P = PL, f = P.t * FPS;
  switch (P.st) {
    case 'idle': if (P.post) { const i = (now() - P.post.t0) / 1000 * FPS; if (i < AN[P.post.n].fr.length) return seq(P.post.n, i); P.post = null; } return AN.idle.fr[(t / 1000 * FPS | 0) % AN.idle.fr.length];
    case 'walk': case 'run': { const a = AN[P.st].fr; return a[((Math.floor(P.ph * FPS) % a.length) + a.length) % a.length]; }
    case 'crouch': return seq('cr_dn', f);
    case 'block': { const g = AN.gd_in.fr.length; return f < g ? seq('gd_in', f) : pp('gd_sw', f - g); }
    case 'jump': if (P.prep > 0) return seq('jp_pre', f); if (P.vy > 350) return seq('jp_up', P.jt * FPS); if (P.vy < -420) return seq('jp_ld', P.y > 70 ? 0 : 1); return seq('jp_ap', Math.max(0, Math.min(1, (350 - P.vy) / 700)) * (AN.jp_ap.fr.length - 1));
    case 'taunt': { const g = AN.tn_in.fr.length; return f < g ? seq('tn_in', f) : P.t < 3.45 ? pp('tn_sw', f - g) : seq('tn_out', (P.t - 3.45) * FPS); }
    case 'hurt': return seq('hurt', f); case 'ko': return seq('ko', f); case 'rise': return seq('ko', AN.ko.fr.length - 1 - f);
  }
  return AN.idle.fr[0];
}
function drawShield(t) {
  const P = PL, c = P.st === 'crouch', F = P.face, x = P.x + 62 * F - camX, y = GY - (c ? 95 : 150) - P.y, r = (c ? 88 : 128) + 4 * Math.sin(t / 70);
  ctx.save(); ctx.globalAlpha = Math.min(1, P.t * 7); ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(x - r * .5 * F, y, r * .15, x - r * .2 * F, y, r); g.addColorStop(0, '#5aa9ff00'); g.addColorStop(.8, '#3b8bff44'); g.addColorStop(1, '#cfe6ffaa');
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(x, y, r * .55, r, 0, F > 0 ? -Math.PI / 2 : Math.PI / 2, F > 0 ? Math.PI / 2 : Math.PI * 1.5); ctx.fill(); ctx.strokeStyle = '#bfe0ffcc'; ctx.lineWidth = 4; ctx.stroke(); ctx.restore();
}
function drawEmote(t) {
  const P = PL; if (P.st !== 'taunt' || !P.emo) return; const a = Math.min(1, (t - P.emo.t) / 220), s = a < 1 ? a * 1.15 : 1 + .04 * Math.sin(t / 160), x = P.x - camX + 30, y = GY - 345 - Math.sin(t / 260) * 5;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#223'; ctx.lineWidth = 4; ctx.beginPath(); ctx.roundRect(-40, -34, 80, 68, 22); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-14, 33); ctx.lineTo(-24, 52); ctx.lineTo(6, 33); ctx.fill(); ctx.font = '46px system-ui,"Apple Color Emoji","Segoe UI Emoji"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(P.emo.e, 0, 3); ctx.restore();
}
