/* basic/strike-engine.js — MESIN serangan "sheet 3x3" (8 frame, sel 256px): pukulan/tendangan dasar & rantai.
   File ini hanya MESIN. Daftar gerakan ada di pukulan_kotak.js dan tendangan_x.js.

   defMove(kunci, opsi) — mendefinisikan satu gerakan:
     sheet : kunci di SHEETS            ms    : milidetik per frame (kecil = cepat)
     dmg   : damage                     kb    : kekuatan dorong (stagger)
     lunge : jarak maju saat memukul    launch: 0 = stagger, 1 = terlempar tinggi, 2 = terlempar kecil
     tip   : [x,y] ujung tangan/kaki tiap frame 0..7 (dipakai untuk efek & jarak jangkauan)
     st    : frame mulai (default 0)    mv: frame mulai maju (default = st)    fh: frame yang memukul (default = ujung terjauh)
     trail : frame efek jejak biru      fxi/fxsc/fxtr: jenis & ukuran efek benturan / jejak
     smoke : nama hook asap di STK_SMOKE    extraBurst: ledakan tambahan   impact:false = tanpa efek benturan
*/
const STK = { S: 1.7, AX: 126, AY: 248 };
STK.K = CFG.CS / STK.S;
const STK_FXSEQ = [[4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], [18, 5, 6, 7, 8, 9, 10, 11, 12, 19]];
const STK_FXDUR = [40, 45, 55, 60, 60, 60, 70, 70, 70, 70, 70];
const STK_SMOKE = {};   // hook asap per gerakan: STK_SMOKE.nama = (skill, move, frame) => { skill.smk(...) }
const MOVES = {};
function defMove(key, o) {
  const m = Object.assign({ launch: 0, st: 0, trail: [], fxi: 0, fxsc: 1, fxtr: 1, impact: true }, o); m.key = key;
  if (m.mv == null) m.mv = m.st;
  if (m.fh != null) m.hit = m.fh; else { let bi = 0, mx = -1; m.tip.forEach((t, f) => { if (t[0] > mx) { mx = t[0]; bi = f; } }); m.hit = bi; }
  m.reach = (m.tip[m.hit][0] - STK.AX) * STK.S; MOVES[key] = m; return m;
}

const pick = a => a[R() * a.length | 0];

class StrikeSkill {
  constructor(firstKey, o = {}) {
    this.auto = o.auto || null; this.kind = o.kind || null; this.variant = o.variant || null; this.step = 1; this.k = STK.K;
    this.ox = PL.x; this.face = PL.face;
    this.x = 0; this.next = null; this.done = false; this.sml = []; this.fxl = []; this.lastHit = 0; this.name = 'strike';
    this.startMove(firstKey); PL.act = this; PL.st = 'act'; PL.blk = false;
    if (PL.charging) Charge.stop(true);
  }
  oppLocal() { return (Opp.x - this.ox) * this.face / this.k; }
  startMove(key) {
    const m = MOVES[key]; this.m = m; this.f = m.st; this.t = 0; this.hitDone = false; this.moveIdx = (this.moveIdx == null ? 0 : this.moveIdx + 1);
    // bantuan bidik: jika lawan agak jauh di depan, tambah luncuran supaya pukulan bisa sampai
    const gap = this.oppLocal() - (this.x + m.reach) - 20; this.lunge = m.lunge;
    if (this.auto && this.auto[key]) this.next = this.auto[key];
    this.smokeHook(m, this.f);
  }
  setNext(key) { this.next = key; }
  tipLocal(m, f, fr) {
    const a = m.tip[Math.min(f, 7)], b = m.tip[Math.min(f + 1, 7)];
    const tx = a[0] + (b[0] - a[0]) * fr, ty = a[1] + (b[1] - a[1]) * fr;
    return [this.x - STK.AX * STK.S + tx * STK.S, -STK.AY * STK.S + ty * STK.S, Math.atan2(b[1] - a[1], Math.max(1, b[0] - a[0]))];
  }
  update(dt) {
    const m = this.m, px0 = this.x;
    if (this.f >= m.mv && this.f < m.hit) this.x += (this.lunge / (Math.max(1, m.hit - m.mv) * m.ms / 1000)) * dt;
    this.t += dt * 1000;
    while (this.t >= m.ms) {
      this.t -= m.ms; this.f++; this.smokeHook(m, this.f);
      if (this.f === m.hit && !this.hitDone) { this.hitDone = true; this.doHit(m); this.spawnImpact(m); }
      if (this.next && this.f > m.hit) { const n = this.next; this.next = null; this.startMove(n); break; }
      if (this.f >= 8) { this.finish(); break; }
    }
    // jangan menembus badan lawan
    const lim = this.oppLocal() - 75; if (px0 <= lim && this.x > lim) this.x = lim;
    this.syncPos();
    for (let i = this.sml.length - 1; i >= 0; i--) { const e = this.sml[i]; e.t += dt * 1000; let tot = 0; for (let j = 0; j < e.seq.length; j++) tot += this.smDur(e, j); if (e.t > tot) this.sml.splice(i, 1); }
    for (let i = this.fxl.length - 1; i >= 0; i--) { const e = this.fxl[i]; e.t += dt * 1000; const tot = e.dur ? e.seq.length * e.dur : STK_FXDUR.slice(0, e.seq.length).reduce((a, b) => a + b, 0); if (e.t > tot) this.fxl.splice(i, 1); }
  }
  syncPos() { PL.x = Math.max(90, Math.min(SW - 120, this.ox + this.face * this.x * this.k)); this.x = (PL.x - this.ox) * this.face / this.k; }
  finish() { this.done = true; PL.act = null; PL.vx = 0; go('idle'); PL.post = null; Combat.strikeEnded(this); }
  cancel() { this.done = true; PL.act = null; }
  doHit(m) {
    this.lastHit = 0; const hx = this.x + m.reach, dx = this.oppLocal() - hx, k = this.k, F = this.face;
    const wx = this.ox + F * hx * k;
    if (Opp.st === 'down' || Opp.st === 'rise' || dx > 90 || dx < -190) { Snd.missSnd(); return; }
    const big = !!m.launch, idx = this.moveIdx;
    Opp.hit({ dmg: m.dmg, type: big ? (m.launch === 2 ? 'airSmall' : 'air') : 'stagger', tm: .25 + .05 * idx,
      vx: (big ? (m.launch === 2 ? 330 : 520) : m.kb * 4.2) * k * F, vy: (m.launch === 2 ? 430 : 720) * k });
    this.lastHit = 1; Snd.hitSnd(big); Combat.hits++;
    hitstop = big ? .13 : .06; shake(big ? 14 : 5 + idx * 2); sparks(wx, GY - 150, F, 8);
  }
  spawnImpact(m) {
    if (!m.impact) return;
    const [x, y] = this.tipLocal(m, m.hit, 0);
    this.fxl.push({ seq: STK_FXSEQ[m.fxi], x, y, sc: m.fxsc * (this.lastHit ? 1 : .7), t: 0, al: this.lastHit ? 1 : .75 });
    if (this.lastHit && m.extraBurst) this.fxl.push({ seq: [10, 11, 12, 13, 14], x: this.oppLocal(), y: -150, sc: m.fxsc * .9, t: -60, al: .8, dur: 90 });
  }
  smk(seq, x, y, sc, dur, delay) { this.sml.push({ seq, x, y, sc: (sc || 1) * 1.35, dur: dur || 60, t: -(delay || 0) }); }
  smDur(e, j) { return Array.isArray(e.dur) ? e.dur[Math.min(j, e.dur.length - 1)] : e.dur; }
  smokeHook(m, f) { const h = m.smoke && STK_SMOKE[m.smoke]; if (h) h(this, m, f); }   // hook asap didaftarkan di file serangan (STK_SMOKE.nama = fn)
  drawBack() {
    localBegin(this.ox, this.face, this.k);
    this.sml.forEach(e => {
      if (e.t < 0) return; let t = e.t, j = 0; for (; j < e.seq.length; j++) { const d = this.smDur(e, j); if (t < d) break; t -= d; } j = Math.min(j, e.seq.length - 1);
      drawSmA(e.seq[j], e.x, e.y, e.sc, .95);
    });
    localEnd();
  }
  drawActor() {
    const m = this.m; localBegin(this.ox, this.face, this.k); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    drawCell(IMG[m.sheet], Math.min(this.f, 7), this.x - STK.AX * STK.S, -STK.AY * STK.S, STK.S); localEnd();
  }
  drawFront() {
    const m = this.m; localBegin(this.ox, this.face, this.k);
    // jejak pukulan menempel di kepalan/kaki sebelum frame kena
    if (m.trail.length) {
      const s = m.hit, st = (s >= 2 && m.tip[s - 2][0] > STK.AX + 45) ? s - 2 : s - 1;
      if (this.f >= st && this.f < s) {
        const fr = Math.min(1, this.t / m.ms), p = ((this.f - st) + fr) / (s - st), tr = m.trail, idx = tr[Math.min(tr.length - 1, Math.floor(p * tr.length))];
        const [x, y, ang] = this.tipLocal(m, this.f, fr); drawFxA(idx, x, y, m.fxtr, Math.max(-.7, Math.min(.7, ang)), Math.min(1, .35 + p));
      }
    }
    this.fxl.forEach(e => {
      if (e.t < 0) return; let t = e.t, j = 0; for (; j < e.seq.length; j++) { const d = e.dur || STK_FXDUR[Math.min(j, STK_FXDUR.length - 1)]; if (t < d) break; t -= d; }
      j = Math.min(j, e.seq.length - 1); drawFxA(e.seq[j], e.x, e.y, e.sc, 0, e.al * (j >= e.seq.length - 2 ? .7 : 1));
    });
    localEnd();
  }
}
