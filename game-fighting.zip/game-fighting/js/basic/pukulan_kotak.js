/* =====================================================================
   basic/pukulan_kotak.js — SERANGAN DASAR □ (pukulan)
   Tombol : □ (SQ)
   Alur   : □ pertama = pukulan acak dari PUNCH_POOL → tekan □ lagi tepat waktu = rantai a2 → a3 → a4 (□□□□)
   Sheet  : 3x3 (8 frame, sel 256px). Gerakan didefinisikan dengan defMove() — penjelasan field ada di basic/strike-engine.js
   ===================================================================== */

/* --- titik ujung tangan [x,y] tiap frame 0..7 untuk tiap gerakan --- */
const TIP_A1 = [[154, 124],[153, 124],[160, 118],[181, 91],[212, 48],[223, 50],[204, 46],[166, 58]];   // a1 pukulan cepat
const TIP_A2 = [[154, 124],[154, 128],[166, 111],[183, 74],[160, 69],[235, 51],[222, 51],[190, 54]];   // a2 pukulan sedang
const TIP_A3 = [[154, 123],[154, 126],[166, 111],[183, 74],[160, 69],[235, 51],[222, 51],[190, 54]];   // a3 pukulan keras
const TIP_A4 = [[154, 123],[152, 127],[162, 124],[191, 99],[168, 88],[209, 63],[236, 57],[210, 97]];   // a4 pukulan terpental
const TIP_B1 = [[153, 124],[152, 129],[161, 124],[190, 99],[167, 89],[208, 63],[235, 58],[209, 97]];   // b1 pukulan keras (pembuka □ acak)

/* --- rantai □□□□ (folder serangan/kombo_kotak4) --- */
defMove('a1', { sheet: 'a1', ms: 48, dmg: 8, lunge: 60, kb: 70, tip: TIP_A1, trail: [0, 1, 2, 3], fxsc: .85, fxtr: 1, fxi: 0 });      // (tersedia, belum dipakai di rantai)
defMove('a2', { sheet: 'a2', ms: 68, dmg: 12, lunge: 70, kb: 110, tip: TIP_A2, trail: [15, 16, 17], fxsc: 1, fxtr: 1.05, fxi: 1 });
defMove('a3', { sheet: 'a3', ms: 84, dmg: 22, lunge: 80, kb: 260, tip: TIP_A3, trail: [0, 1, 2, 3], fxsc: 1.2, fxtr: 1.15, fxi: 0 });
defMove('a4', { sheet: 'a4', ms: 104, dmg: 40, lunge: 90, kb: 420, launch: 1, tip: TIP_A4, trail: [15, 16, 17], fxsc: 1.6, fxtr: 1.3, fxi: 1 });
/* --- pembuka □ tambahan: pukulan keras (sheet dari folder kombo B) --- */
defMove('b1', { sheet: 'b1', ms: 60, dmg: 12, lunge: 60, kb: 120, st: 2, tip: TIP_B1, trail: [0, 1, 2, 3], fxsc: .9, fxtr: 1, fxi: 0 });

/* --- serangan dasar □ (acak): sheet dari folder serangan/dasar, titik tangan dari DATA.basic --- */
const BASIC_FILES = ['atk1', 'atk2', 'atk3', 'atk5', 'atk6', 'atk7'];
DATA.basic.forEach((b, i) => { defMove('p_' + BASIC_FILES[i], { sheet: BASIC_FILES[i], ms: 55, dmg: 8, lunge: 50, kb: 90, st: b.st, tip: b.tip, trail: [0, 1, 2, 3], fxsc: .9, fxtr: 1, fxi: 0, fh: b.hit, basic: true }); });
const PUNCH_POOL = BASIC_FILES.map(f => 'p_' + f).concat(['b1']);   // pembuka □ dipilih acak dari sini

Combos.add({
  id: 'pukulan_kotak', nama: 'Pukulan □ (rantai □□□□)', keys: 'SQ',
  ket: 'Tekan □ berulang = combo pukulan 4x (arah sesuai hadap)',
  sheets: {
    atk1: 'serangan/dasar/attack_01.png', atk2: 'serangan/dasar/attack_02.png', atk3: 'serangan/dasar/attack_03.png',
    atk5: 'serangan/dasar/attack_05.png', atk6: 'serangan/dasar/attack_06.png', atk7: 'serangan/dasar/attack_07.png',
    a1: 'serangan/kombo_kotak4/1_pukulan_cepat.png', a2: 'serangan/kombo_kotak4/2_pukulan_sedang.png',
    a3: 'serangan/kombo_kotak4/3_pukulan_keras_knockback.png', a4: 'serangan/kombo_kotak4/4_pukulan_terpental.png',
    b1: 'serangan/kombo_x_kotak_segitiga_B/1_pukulan_keras.png',
  },
  /* RANTAI: setelah gerakan pembuka, tiap tombol `key` yang ditekan tepat waktu (CFG.CHAIN_WINDOW) menyambung ke `move` berikutnya.
     Langkah terakhir otomatis jadi penutup (rantai selesai). */
  chain: {
    pool: PUNCH_POOL,
    steps: [{ key: 'SQ', move: 'a2' }, { key: 'SQ', move: 'a3' }, { key: 'SQ', move: 'a4' }],
  },
});
