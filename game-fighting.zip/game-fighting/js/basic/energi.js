/* =====================================================================
   basic/energi.js — ○ (TAHAN) = mengumpulkan energi: sprite 8 frame + aura/efek biru + suara.
   Tombol : ○ (CI), tahan. Lepas = selesai. Bar energi tampil di HUD (PL.energy).
   ===================================================================== */
const Charge = {
  t: 0, phase: 'in', snd: null, fxT: 0, hitT: 0,
  start() {
    if (PL.charging || !canAct()) return; PL.charging = true; go('charge'); this.t = 0; this.phase = 'in'; this.fxT = 0;
    if (this.snd) this.snd.stop(.05); this.snd = Snd.play('charge', { loop: true, vol: .7, off: 0, dur: 1.0 });
    Snd.pop();
  },
  stop(force) {
    if (!PL.charging) return;
    if (this.snd) { this.snd.stop(force ? .05 : .25); this.snd = null; }
    if (force) { PL.charging = false; if (PL.st === 'charge') go('idle'); return; }
    if (this.phase !== 'out') { this.phase = 'out'; this.t = 0; }
  },
  frame() {
    const t = this.t;
    if (this.phase === 'in') return Math.min(5, Math.floor(t / .07));
    if (this.phase === 'loop') return [3, 4, 5, 4][Math.floor(t / .12) % 4];
    return [6, 7][Math.min(1, Math.floor(t / .09))];
  },
  update(dt) {
    if (!PL.charging) { PL.energy = Math.max(0, PL.energy - 6 * dt); return; }
    this.t += dt;
    if (this.phase === 'in' && this.t > .42) { this.phase = 'loop'; this.t = 0; }
    if (this.phase === 'loop') {
      PL.energy = Math.min(100, PL.energy + 38 * dt);
      if (!K.CI && !GP.CI && !KB.CI) this.stop();
      this.fxT -= dt;
      if (this.fxT <= 0) {
        this.fxT = .28 - .1 * PL.energy / 100; const x = PL.x + (R() - .5) * 60;
        spr(FXI.slice(10, 13), x, GY - 110, { anc: 'c', fps: 9, sc: .9 + PL.energy / 160, add: 1 });
        spr(FXI.slice(13, 15), PL.x + (R() - .5) * 120, GY - 60 - R() * 140, { anc: 'c', fps: 7, sc: .8, add: 1, vx: 0 });
      }
    } else if (this.phase === 'in') { if (!K.CI && !GP.CI && !KB.CI && this.t > .14) this.stop(); }
    else if (this.phase === 'out' && this.t > .2) { PL.charging = false; go('idle'); PL.post = null; }
  },
  drawActor() {
    const a = DATA.charge[this.frame()], F = PL.face;
    cellActor(IMG.charge, this.frame(), PL.x, 0, F, a.c, a.b, CFG.CS, 0);
  },
  drawFront(t) {
    if (this.phase === 'out' && this.t > .1) return; const e = PL.energy / 100, F = PL.face;
    const x = PL.x - camX + 10 * F, y = GY - 140, r = 120 + 70 * e + 10 * Math.sin(t / 90);
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(x, y, 6, x, y, r);
    g.addColorStop(0, `rgba(190,225,255,${.35 + .3 * e})`); g.addColorStop(.45, `rgba(70,150,255,${.25 + .2 * e})`); g.addColorStop(1, 'rgba(30,100,255,0)');
    ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2);
    ctx.strokeStyle = `rgba(150,210,255,${.4 + .3 * e})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x, GY + 4, 70 + 30 * e + 6 * Math.sin(t / 70), 14, 0, 0, 7); ctx.stroke(); ctx.restore();
  },
};

Combos.add({
  id: 'energi', nama: 'Kumpulkan energi', keys: 'CI', hold: true, keepChain: true,
  ket: 'Tahan ○ — aura biru + suara energi',
  sheets: { charge: 'energi/mengumpulkan_energi.png' },
  sounds: { charge: 'suara/energi/mengumpulkan_energi.mp3' },
  launch: () => Charge.start(),
});
