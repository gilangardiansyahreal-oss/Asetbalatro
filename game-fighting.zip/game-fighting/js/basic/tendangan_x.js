/* =====================================================================
   basic/tendangan_x.js — SERANGAN DASAR ✕ (tendangan)
   Tombol : ✕ (X) / Spasi
   Alur   : ✕ pertama = tendangan/lutut ringan acak (KICK_POOL)
            → □ = langkah 2, → △ = langkah 3 (penutup). Ada 2 variasi, dipilih per CFG.VARIASI_X_KOTAK_SEGITIGA:
              B : lutut (b2) → tendangan mental (b3)
              C : lutut (c2) → lompat ke depan (c1) lalu otomatis banting dari atas (c3) + asap kaki
   ===================================================================== */

/* --- titik ujung kaki [x,y] tiap frame 0..7 --- */
const TIP_B2 = [[153, 130],[152, 135],[165, 125],[158, 171],[180, 159],[194, 129],[191, 136],[170, 161]];   // b2 lutut
const TIP_B3 = [[153, 129],[152, 130],[152, 146],[174, 160],[217, 168],[221, 184],[168, 189],[150, 147]];   // b3 tendangan mental
const TIP_C1 = [[153, 124],[149, 129],[158, 175],[166, 182],[169, 83],[175, 73],[173, 87],[170, 110]];   // c1 lompat ke depan
const TIP_C2 = [[152, 130],[152, 132],[165, 125],[158, 171],[180, 159],[194, 129],[191, 135],[170, 161]];   // c2 lutut
const TIP_C3 = [[153, 124],[153, 131],[151, 158],[159, 181],[161, 180],[181, 57],[159, 108],[196, 64]];   // c3 banting dari atas

/* --- variasi B (folder kombo_x_kotak_segitiga_B) --- */
defMove('b2', { sheet: 'b2', ms: 72, dmg: 18, lunge: 50, kb: 220, st: 2, tip: TIP_B2, trail: [7, 8], fxsc: 1.05, fxtr: .9, fxi: 1 });
defMove('b3', { sheet: 'b3', ms: 80, dmg: 28, lunge: 70, kb: 300, launch: 2, st: 2, tip: TIP_B3, trail: [7, 8], fxsc: 1.4, fxtr: 1.15, fxi: 0, extraBurst: true });
/* --- variasi C (folder kombo_x_kotak_segitiga_C), memakai asap kaki --- */
defMove('c1', { sheet: 'c1', ms: 70, dmg: 6, lunge: 210, kb: 90, st: 2, mv: 4, fh: 7, tip: TIP_C1, trail: [], fxsc: .9, fxtr: 1, impact: false, smoke: 'c1' });
defMove('c2', { sheet: 'c2', ms: 72, dmg: 16, lunge: 50, kb: 200, st: 2, tip: TIP_C2, trail: [7, 8], fxsc: 1.05, fxtr: .9, fxi: 1, smoke: 'c2' });
defMove('c3', { sheet: 'c3', ms: 95, dmg: 30, lunge: 40, kb: 330, launch: 2, st: 2, fh: 7, tip: TIP_C3, trail: [0, 1, 2, 3], fxsc: 1.3, fxtr: 1, fxi: 0, extraBurst: true, smoke: 'c3' });

/* --- hook asap kaki per gerakan (dipanggil engine tiap ganti frame). s = skill, m = gerakan, f = frame --- */
STK_SMOKE.c1 = (s, m, f) => {
  if (f === 4) s.smk([0, 1, 2, 3, 4, 5], s.x, 0, 1, [55, 60, 65, 70, 80, 90]);
  if (f === 5) s.smk([12, 13, 14, 15, 16], s.x - 20, 0, 1, 60);
  if (f === m.hit) s.smk([6, 7, 8, 9, 10, 11], s.x + 10, 0, .95, [50, 55, 60, 70, 80, 90]);
};
STK_SMOKE.c2 = (s, m, f) => { if (f === m.st + 1) s.smk([12, 13, 14], s.x - 10, 0, .8, 60); };
STK_SMOKE.c3 = (s, m, f) => {
  const hx = s.x + m.reach;
  if (f === m.hit - 1) s.smk([17, 18, 19], hx, 0, 1, 70);
  if (f === m.hit) { s.smk([20, 21, 22], hx, 0, 1.1, [70, 90, 110]); s.smk([6, 7, 8, 9, 10, 11], hx, 0, 1.15, [50, 55, 60, 70, 80, 90], 40); }
};

/* --- tendangan ✕ pembuka (acak): kaki/lutut dari sprite B & C, dibuat ringan --- */
const LIGHT = { dmg: 10, kb: 150, launch: 0, ms: 66, lunge: 55, basic: true };
defMove('k_tendang', Object.assign({}, MOVES.b3, LIGHT, { sheet: 'b3', tip: TIP_B3, fh: undefined, fxsc: .95, smoke: null, extraBurst: false }));
defMove('k_lutut1', Object.assign({}, MOVES.b2, LIGHT, { sheet: 'b2', tip: TIP_B2, fh: undefined, fxsc: .9 }));
defMove('k_lutut2', Object.assign({}, MOVES.c2, LIGHT, { sheet: 'c2', tip: TIP_C2, fh: undefined, fxsc: .9, smoke: 'c2' }));
const KICK_POOL = ['k_tendang', 'k_lutut1', 'k_lutut2'];

let _varN = 0;   // penghitung untuk mode 'selang'
Combos.add({
  id: 'tendangan_x', nama: 'Tendangan ✕ (rantai ✕ □ △)', keys: 'X',
  ket: '✕ → □ → △ = tendang, lutut, tendangan mental / banting',
  sheets: {
    b2: 'serangan/kombo_x_kotak_segitiga_B/2_lutut.png', b3: 'serangan/kombo_x_kotak_segitiga_B/3_tendangan_mental.png',
    c1: 'serangan/kombo_x_kotak_segitiga_C/1_lompat_ke_depan.png', c2: 'serangan/kombo_x_kotak_segitiga_C/2_lutut.png',
    c3: 'serangan/kombo_x_kotak_segitiga_C/3_banting_dari_atas.png',
  },
  chain: {
    pool: KICK_POOL,
    pick() {   // memilih variasi B / C
      const m = CFG.VARIASI_X_KOTAK_SEGITIGA; if (m === 'B' || m === 'C') return m;
      if (m === 'selang') return (_varN++ % 2) ? 'C' : 'B'; return R() < .5 ? 'B' : 'C';
    },
    variants: {
      B: [{ key: 'SQ', move: 'b2' }, { key: 'TRI', move: 'b3' }],
      C: [{ key: 'SQ', move: 'c2' }, { key: 'TRI', move: 'c1', auto: { c1: 'c3' } }],   // auto: setelah c1 langsung lanjut c3 tanpa tombol
    },
  },
});
