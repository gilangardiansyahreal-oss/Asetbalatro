#!/usr/bin/env python3
"""Gabungkan seluruh proyek jadi SATU file html (seperti versi lama, bisa dibuka dengan klik dua kali).
   Pakai:  python3 build_satu_file.py   →  hasil: game_satu_file.html
   Urutan script mengikuti index.html; gambar & suara di-embed base64 ke window.__EMBED."""
import re, base64, os, sys
root = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(root, 'index.html'), encoding='utf-8').read()
css = open(os.path.join(root, 'css/style.css'), encoding='utf-8').read()
html = re.sub(r'<!--(?!\s*1\. CONFIG)[\s\S]*?-->', '', html)   # buang komentar HTML (kecuali penanda sisip embed)
html = html.replace('<link rel="stylesheet" href="css/style.css">', '<style>' + css + '</style>')
def inline(m):
    js = open(os.path.join(root, m.group(1)), encoding='utf-8').read().replace('</script', '<\\/script')
    return '<script>' + js + '</script>'
def mime(b):
    if b[:4] == b'RIFF' and b[8:12] == b'WEBP': return 'image/webp'
    if b[:8] == b'\x89PNG\r\n\x1a\n': return 'image/png'
    return 'audio/mpeg'
emb = []
for d, _, fs in os.walk(os.path.join(root, 'assets')):
    for f in fs:
        if f.endswith('.json'): continue
        p = os.path.join(d, f); b = open(p, 'rb').read()
        emb.append('"%s":"data:%s;base64,%s"' % (os.path.relpath(p, os.path.join(root, 'assets')).replace(os.sep, '/'), mime(b), base64.b64encode(b).decode()))
embed = '<script>window.__EMBED={' + ','.join(emb) + '};</script>'
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
html = html.replace('<!-- 1. CONFIG', embed + '\n<!-- 1. CONFIG', 1)
out = os.path.join(root, 'game_satu_file.html'); open(out, 'w', encoding='utf-8').write(html)
print('OK ->', out, round(os.path.getsize(out) / 1e6, 1), 'MB')
