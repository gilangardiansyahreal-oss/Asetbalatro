# Game Fighting – Jurus Lengkap (versi terstruktur)

Game 2D fighting (HTML5 canvas, JavaScript biasa, tanpa bundler). File 6 MB lama sudah dipecah:
**kode kecil per fitur** + **aset di folder `assets/`**. Menambah combo = menambah 1 file kecil.

## Menjalankan
- Lokal: `python3 -m http.server` di folder ini → buka `http://localhost:8000` (harus lewat server, bukan klik dua kali).
- GitHub Pages: upload seluruh folder apa adanya.
- Satu file (klik dua kali): `python3 build_satu_file.py` → `game_satu_file.html`.

## Peta folder
```
index.html              kerangka + URUTAN <script> (combo baru didaftarkan di sini, 1 baris)
css/style.css           tampilan HUD & tombol layar
assets/                 gambar (webp/png) & suara (mp3) — AI tidak perlu membukanya, lihat docs/DAFTAR_ASET.md
docs/
  DAFTAR_ASET.md        kunci sheet/suara/efek + ukuran + grid frame (otomatis)
  TOMBOL_COMBO.md       tombol yang sudah dipakai & kombinasi yang masih kosong (otomatis)
js/
  config/   config.js   pengaturan umum, KEYMAP (keyboard), PADMAP (gamepad)
            aset.js     daftar suara dasar (jalan, kena, meleset)
  data/     sprite-data.js, manifest.js   data otomatis dari sprite — jangan diedit
  system/   assets.js   pemuat aset            audio.js   suara (Snd)
            render.js   kanvas/kamera/gambar   effects.js efek (spr, dust, sparks)
            background.js latar                input.js   keyboard/gamepad/tombol layar
            hud.js      HUD & panel bantuan    main.js    loop utama
  logic/    combo-registry.js  pendaftaran combo (Combos.add)   ← inti sistem
            combat.js          pengatur tombol → serangan/combo/rantai
            player.js          gerak dasar pemain              opponent.js  lawan latihan
  basic/    strike-engine.js   mesin serangan sheet 3x3
            pukulan_kotak.js   □ pukulan + rantai □□□□
            tendangan_x.js     ✕ tendangan + rantai ✕□△ (varian B/C)
            energi.js          ○ tahan = kumpulkan energi
  combos/   _engine.js         mesin combo deklaratif (BACA header-nya untuk format)
            kuda_kuda.js       R2+□   (deklaratif: slide → bertubi → tendang)
            lompat_tinggi.js   △ → ✕ → □ (bertahap)
            brondolan.js       L1+○        ompreng.js  R1+△        kopdes.js  L1+△
            _TEMPLATE_combo_baru.js   salin untuk combo baru (tidak dimuat game)
```

## Menambah combo baru (untuk manusia & AI)
Baca hanya: file ini, `docs/TOMBOL_COMBO.md`, `docs/DAFTAR_ASET.md`, header `js/combos/_engine.js`, dan contoh `js/combos/kuda_kuda.js`. **Jangan** buka `assets/`.

1. Salin `js/combos/_TEMPLATE_combo_baru.js` → `js/combos/nama.js`; ganti `id`, `nama`, `keys`, `toast`, `label`, `ket`.
2. `keys`: `'R2+SQ'` (tahan modifier L1/R1/R2 lalu tombol) atau `'TRI'` (tombol saja). Pilih yang kosong di `docs/TOMBOL_COMBO.md`. Konsol (F12) memberi peringatan bila ganda.
3. Aset baru: taruh di `assets/`, daftarkan di `sheets:{kunci:'path'}` / `sounds:{kunci:'path'}` pada file combo itu.
4. Isi `tips` + `stages`. Contoh satu tahap:
```js
slide: {
  img:'ns', k:'s',            // sheet & kunci titik ujung di `tips`
  f0:7, f1:19,                // frame 7 sampai 19
  ms:58,                      // milidetik per frame (kecil = cepat)
  xs:[[9,0],[15,108]],        // maju: frame 9 posisi 0 → frame 15 maju 108 (108 ≈ 1 m)
  h:{15:{o:{dmg:12,type:'stagger',vx:260,tm:.3}, stun:3}}   // frame 15 memukul
}
```
   Field lain (`snd, smoke, ghost, tr/trI, on, cols`) dijelaskan di header `_engine.js`.
5. Tambahkan 1 baris di `index.html` bagian COMBO: `<script src="js/combos/nama.js"></script>`.

Skill dengan kode khusus (seperti kopdes) cukup membuat class skill lalu `Combos.add({ ..., launch: () => new SkillBaru() })`;
class itu wajib punya `update(dt)`, `drawActor()`, `cancel()`, dan memanggil `Combat.afterSkill()` saat selesai (lihat `ompreng.js` — paling ringkas).

## Fungsi bantu yang boleh dipanggil di `on:{frame: s=>...}`
`spr(frames,x,y,{anc,fps,sc,add,vx})` · `dust('lompat'|'jatuh'|'samping'|'falling', x, skala, vx)` · `sparks(x,y,face,n)` · `dmgText(teks,x,y,warna)` · `shake(n)` · `hitstop = detik` · `Snd.play('kunci',{off,dur,vol,fade})` · `Opp.hit({dmg,type,vx,vy,tm})` · `s.wx(xLokal)` (posisi dunia) · `s.face` (arah hadap ±1) · `GY` (tanah).

## Yang berubah dari file lama
- Perilaku game **sama** (diuji: 19 skenario tombol dibandingkan frame demi frame dengan file asli, hasil identik; dicek juga di Chrome tanpa error).
- Daftar combo tidak lagi di `config`; tiap combo/serangan mendaftar sendiri lewat `Combos.add`, termasuk tombol pemicunya.
- Kode mati dibuang: sistem urutan tombol lama (`SEQS`, `seqPress`, pose kopdes dari urutan) yang sudah tertimpa patch `combo_baru`; `SEQ_TIMEOUT` & `OMPRENG_TIMEOUT` di config.
- Status "Skill: ..." kini terisi untuk Kuda-kuda (dulu kosong).
