# Daftar aset (dibuat otomatis)

Semua path relatif ke folder `assets/`. **Kunci** = nama yang dipakai di kode (`IMG.kunci`, `Snd.play('kunci')`).
AI/pemrogram: cukup baca file ini — tidak perlu membuka gambar/suara satu-satu.

## Sprite sheet (`SHEETS` → `IMG.kunci`)

Sel selalu 256×256 px. Grid 3×3 = 8 frame (serangan dasar/skill) · 5×5 = 25 frame (combo deklaratif seperti kuda-kuda). Frame dihitung kiri→kanan, atas→bawah mulai 0.

| kunci | file | ukuran | grid sel 256px | dipakai oleh |
|---|---|---|---|---|
| `a1` | `serangan/kombo_kotak4/1_pukulan_cepat.png` | 768×768 | 3×3 | pukulan_kotak |
| `a2` | `serangan/kombo_kotak4/2_pukulan_sedang.png` | 768×768 | 3×3 | pukulan_kotak |
| `a3` | `serangan/kombo_kotak4/3_pukulan_keras_knockback.png` | 768×768 | 3×3 | pukulan_kotak |
| `a4` | `serangan/kombo_kotak4/4_pukulan_terpental.png` | 768×768 | 3×3 | pukulan_kotak |
| `atk1` | `serangan/dasar/attack_01.png` | 768×768 | 3×3 | pukulan_kotak |
| `atk2` | `serangan/dasar/attack_02.png` | 768×768 | 3×3 | pukulan_kotak |
| `atk3` | `serangan/dasar/attack_03.png` | 768×768 | 3×3 | pukulan_kotak |
| `atk5` | `serangan/dasar/attack_05.png` | 768×768 | 3×3 | pukulan_kotak |
| `atk6` | `serangan/dasar/attack_06.png` | 768×768 | 3×3 | pukulan_kotak |
| `atk7` | `serangan/dasar/attack_07.png` | 768×768 | 3×3 | pukulan_kotak |
| `b1` | `serangan/kombo_x_kotak_segitiga_B/1_pukulan_keras.png` | 768×768 | 3×3 | pukulan_kotak |
| `b2` | `serangan/kombo_x_kotak_segitiga_B/2_lutut.png` | 768×768 | 3×3 | tendangan_x |
| `b3` | `serangan/kombo_x_kotak_segitiga_B/3_tendangan_mental.png` | 768×768 | 3×3 | tendangan_x |
| `brMakan` | `skill/brondolan/makan.png` | 768×768 | 3×3 | brondolan |
| `brPeluru` | `skill/brondolan/peluru_strip_15frame.png` | 3000×100 | (strip / bukan grid 256) | brondolan |
| `brSemb` | `skill/brondolan/menyembur.png` | 768×768 | 3×3 | brondolan |
| `c1` | `serangan/kombo_x_kotak_segitiga_C/1_lompat_ke_depan.png` | 768×768 | 3×3 | tendangan_x |
| `c2` | `serangan/kombo_x_kotak_segitiga_C/2_lutut.png` | 768×768 | 3×3 | tendangan_x |
| `c3` | `serangan/kombo_x_kotak_segitiga_C/3_banting_dari_atas.png` | 768×768 | 3×3 | tendangan_x |
| `charge` | `energi/mengumpulkan_energi.png` | 768×768 | 3×3 | energi |
| `d1` | `serangan/kombo_segitiga_x_kotak/1_lompat_tinggi.png` | 768×768 | 3×3 | lompat_tinggi |
| `d2` | `serangan/kombo_segitiga_x_kotak/2_di_udara.png` | 768×768 | 3×3 | lompat_tinggi |
| `d3` | `serangan/kombo_segitiga_x_kotak/3_turun_knockback.png` | 768×768 | 3×3 | lompat_tinggi |
| `nk` | `karakter/combo/tendang.png` | 1280×1280 | 5×5 | kuda_kuda |
| `np` | `karakter/combo/bertubi.png` | 1280×1280 | 5×5 | kuda_kuda |
| `ns` | `karakter/combo/slide.png` | 1280×1280 | 5×5 | kuda_kuda |
| `omLempar` | `skill/ompreng/melempar.png` | 768×768 | 3×3 | ompreng |
| `omTray` | `skill/ompreng/ompreng_strip.png` | 2172×724 | (strip / bukan grid 256) | ompreng |

## Suara (`SOUNDS` → `Snd.play('kunci',{off,dur,vol,fade,loop,rate,norm})`)

`off` & `dur` = potong bagian mp3 (detik). Durasi file di tabel membantu memilih potongan.

| kunci | file | durasi (dtk) | dipakai oleh |
|---|---|---|---|
| `airMid` | `suara/gerak/di_udara.mp3` | 0.84 | lompat_tinggi |
| `brEat` | `suara/skill/brondolan_makan.mp3` | 1.44 | brondolan |
| `brShot` | `suara/skill/brondolan_tembakan.mp3` | 1.22 | brondolan |
| `cKick` | `suara/combo/tendang.mp3` | 8.49 | kuda_kuda |
| `cPunch` | `suara/combo/bertubi.mp3` | 7.84 | kuda_kuda |
| `cSlide` | `suara/combo/slide.mp3` | 1.03 | kuda_kuda |
| `charge` | `suara/energi/mengumpulkan_energi.mp3` | 1.03 | energi |
| `hit1` | `suara/serangan/kena_musuh_1.mp3` | 2.04 | sistem (jalan/kena/meleset) |
| `hit2` | `suara/serangan/kena_musuh_2.mp3` | 2.04 | sistem (jalan/kena/meleset) |
| `hit3` | `suara/serangan/kena_musuh_3.mp3` | 1.54 | sistem (jalan/kena/meleset) |
| `jumpHigh` | `suara/gerak/lompat_tinggi.mp3` | 0.16 | lompat_tinggi |
| `kopRumble1` | `suara/skill/kopdes_rumble1_jongkok_dan_kopdes.mp3` | 1.54 | kopdes |
| `kopRumble3` | `suara/skill/kopdes_rumble3_pukulan.mp3` | 1.54 | kopdes |
| `miss` | `suara/serangan/meleset.mp3` | 4.13 | sistem (jalan/kena/meleset) |
| `omAir` | `suara/skill/ompreng_di_udara.mp3` | 2.04 | ompreng |
| `omHit` | `suara/skill/ompreng_kena_musuh.mp3` | 2.04 | ompreng |
| `omThrow` | `suara/skill/ompreng_dilempar.mp3` | 2.04 | ompreng |
| `run` | `suara/gerak/run.mp3` | 1.03 | sistem (jalan/kena/meleset) |
| `slamLand` | `suara/gerak/mendarat_banting.mp3` | 1.96 | lompat_tinggi |
| `taunt` | `suara/gerak/taunt.mp3` | 3.81 | sistem (jalan/kena/meleset) |
| `walk` | `suara/gerak/walk.mp3` | 2.04 | sistem (jalan/kena/meleset) |
| `walk2` | `suara/gerak/walk2.mp3` | 2.04 | sistem (jalan/kena/meleset) |

## Efek biru `FXI[index]` (aditif) — dipakai `spr(FXI.slice(a,b),...)`, `drawFxA(index,...)`

| index | file | ukuran |
|---|---|---|
| 0 | `efek/biru/fx01_trail1.png` | 177×129 |
| 1 | `efek/biru/fx02_trail2.png` | 220×125 |
| 2 | `efek/biru/fx03_trail3.png` | 224×124 |
| 3 | `efek/biru/fx04_trail4.png` | 230×134 |
| 4 | `efek/biru/fx05_impact1.png` | 220×155 |
| 5 | `efek/biru/fx06_burst1.png` | 177×176 |
| 6 | `efek/biru/fx07_burst2.png` | 228×175 |
| 7 | `efek/biru/fx08_after1.png` | 213×155 |
| 8 | `efek/biru/fx09_after2.png` | 207×132 |
| 9 | `efek/biru/fx10_fade1.png` | 180×122 |
| 10 | `efek/biru/fx11_swirl1.png` | 175×109 |
| 11 | `efek/biru/fx12_swirl2.png` | 161×102 |
| 12 | `efek/biru/fx13_swirl3.png` | 163×78 |
| 13 | `efek/biru/fx14_spark1.png` | 153×57 |
| 14 | `efek/biru/fx15_spark2.png` | 51×39 |
| 15 | `efek/biru/fx16_v2trail1.png` | 177×123 |
| 16 | `efek/biru/fx17_v2trail2.png` | 230×119 |
| 17 | `efek/biru/fx18_v2trail3.png` | 230×117 |
| 18 | `efek/biru/fx19_v2impact.png` | 221×123 |
| 19 | `efek/biru/fx20_v2fade.png` | 164×105 |

Kelompok siap pakai: `FXS.hit` = FXI[4..7] (benturan), `FXS.sw` = gelombang. Contoh pukulan besar: `FXI.slice(8,10)`, `FXI.slice(18,20)`, aura `FXI.slice(10,13)`.

## Efek asap `SMI[index]` — dipakai `dust(nama, x, skala, vx)` atau `spr(SM.nama, ...)`

| nama kelompok | index SMI | dipakai lewat |
|---|---|---|
| lompat | 0–5 | `dust('lompat', x, skala)` |
| jatuh | 6–11 | `dust('jatuh', x, skala)` |
| samping | 12–16 | `dust('samping', x, skala, vx)` |
| falling | 17–22 | `dust('falling', x, skala)` |

## Animasi dasar 30 FPS (`AN.nama.fr[i]`) — gerak dasar pemain & lawan (otomatis, jarang perlu disentuh)

| animasi | jumlah frame |
|---|---|
| `idle` | 32 |
| `walk` | 24 |
| `run` | 18 |
| `cr_dn` | 13 |
| `cr_up` | 11 |
| `tn_in` | 13 |
| `tn_sw` | 7 |
| `tn_out` | 10 |
| `hurt` | 22 |
| `ko` | 29 |
| `gd_in` | 7 |
| `gd_sw` | 7 |
| `gd_out` | 7 |
| `jp_pre` | 5 |
| `jp_up` | 5 |
| `jp_ap` | 5 |
| `jp_ld` | 7 |
