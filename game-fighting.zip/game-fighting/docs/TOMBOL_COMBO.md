# Tombol yang dipakai (dibuat otomatis dari `keys` tiap combo)

Sebelum membuat combo baru, pilih kombinasi tombol yang **belum** ada di tabel ini. Sistem akan memberi peringatan di konsol (F12) bila ada tombol ganda.

Keyboard: **L1**=Q · **R1**=E · **R2**=F · **△**=I · **□**=J · **✕**=K / Spasi · **○**=L · L2=Shift (jalan⇄lari) · R=Taunt.  `+` artinya tahan modifier lalu tekan tombol wajah (modifier yang baru dilepas masih berlaku 0,6 dtk).

| combo (`id`) | `keys` | keyboard | jenis | file |
|---|---|---|---|---|
| pukulan_kotak | `SQ` | J | rantai serangan dasar | `js/basic/pukulan_kotak.js` |
| tendangan_x | `X` | K | rantai serangan dasar | `js/basic/tendangan_x.js` |
| energi | `CI` | L | tombol tahan | `js/basic/energi.js` |
| lompat_tinggi | `TRI` (TRI → X → SQ) | I → K → J | skill class (kode khusus) | `js/combos/lompat_tinggi.js` |
| kuda_kuda | `R2+SQ` | F + J | deklaratif (stages) | `js/combos/kuda_kuda.js` |
| brondolan | `L1+CI` | Q + L | skill class (kode khusus) | `js/combos/brondolan.js` |
| ompreng | `R1+TRI` | E + I | skill class (kode khusus) | `js/combos/ompreng.js` |
| kopdes | `L1+TRI` | Q + I | skill class (kode khusus) | `js/combos/kopdes.js` |

**Kombinasi modifier yang masih KOSONG** (bebas dipakai combo baru):

`L1+SQ`, `L1+X`, `R1+SQ`, `R1+X`, `R1+CI`, `R2+X`, `R2+TRI`, `R2+CI`

